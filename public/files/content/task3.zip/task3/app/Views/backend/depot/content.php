<?= $this->extend('backend/_layouts/general') ?>

<?= $this->section('subHeader_actions') ?>
<!--begin::Toolbar-->
<div class="d-flex align-items-center">
    <!--begin::Actions BTN-->
    <div class="d-flex align-items-center">
        <a href="<?= base_url('admin/depot/add-item'); ?>" class="btn btn-sm btn-primary font-weight-bold mr-2" title="Přidat položku" data-placement="left">
            <span class="text-gray font-size-base">Přidat položku</span>
        </a>

        <!--<a data-toggle="modal" data-target="#categoryModal" class="btn btn-sm btn-primary font-weight-bold mr-2" title="Přidat typ" data-placement="left">
                <span class="text-gray font-size-base">Přidat typ</span>
            </a>-->
    </div>
    <!--end::Actions BTN-->
</div>
<!--end::Toolbar-->
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<!--begin::Dashboard-->
<!--TODO: start_component-->
<!--begin::Card-->
<div class="card card-custom">
    <div class="card-header flex-wrap pt-6 pb-0 card-header-tabs-line depot-nav">
        <div class="card-title">
            <h3 class="card-label">Sklad</h3>
        </div>

        <div class="card-toolbar">
            <ul class="nav nav-tabs nav-bold nav-tabs-line undivided-tabs">
                <li class="nav-item">
                    <a class="nav-link active has-search" data-inputid="depotTableSearch" data-toggle="tab" href="#items_tab_pane">Aktivní sklad</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link has-search" data-fn="initEmptyTable" data-inputid="emptyTableSearch" data-toggle="tab" href="#empty_tab_pane">Ceníkové položky</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link has-search" data-fn="initInactiveTable" data-inputid="inactiveTableSearch" data-toggle="tab" href="#inactive_tab_pane">Neaktivní</a>
                </li>

                <ul class="nav nav-tabs nav-bold nav-tabs-line divided-tabs">
                    <li class="nav-item">
                        <a class="nav-link has-search" data-fn="initMaterialTable" data-inputid="materialTableSearch" data-toggle="tab" href="#material_tab_pane">Materiály</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link has-search" data-fn="initCategoryTable" data-inputid="categoryTableSearch" data-toggle="tab" href="#categories_tab_pane">Kategorie</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link has-search" data-fn="initDepotsTable" data-inputid="depotsTableSearch" data-toggle="tab" href="#depots_tab_pane">Sklady</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link has-search" data-fn="initAlertsTable" data-inputid="alertsTableSearch" data-toggle="tab" href="#alerts_tab_pane">Upozornění</a>
                    </li>
                </ul>
            </ul>
        </div>
    </div>

    <div class="input-group">
        <!-- <input class="table-search form-control" id="depotTableSearch" placeholder="Hledat položku.."> -->
        <div class="accordion accordion-light accordion-toggle-arrow mb-5 ml-2" id="filter_accordion">
                <div class="card">
                    <div class="card-header">
                        <h6 class="card-title collapsed" data-toggle="collapse" data-target="#filter_collapse">
                            <i class="fas fa-filter"></i> Filtrovat
                        </h6>
                    </div>
                    <div id="filter_collapse" class="collapse" data-parent="#filter_accordion">
                        <div class="card-body my-5">

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <input type="text" class="form-control form-control-sm filter-input" data-field="name" placeholder="Název">
                                        </div>
                                        <div class="col-md-3">
                                            <input type="text" class="form-control form-control-sm filter-input" data-field="barcode" placeholder="SAP">
                                        </div>
                                        <div class="col-md-3">
                                            <input data-field="material_weight" type="text" placeholder="Gramáž" class="form-control form-control-sm filter-input" />
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-3">
                                            <input type="text" class="form-control form-control-sm filter-input" data-field="material_width" placeholder="Formát" />
                                        </div>
                                        <div class="col-md-3">
                                            <input type="text" data-field="Dostupné" class="form-control form-control-sm filter-input" placeholder="available_quantity">
                                        </div>
                                        <div class="col-md-3">
                                            <input type="text" data-field="categoryName" class="form-control form-control-sm filter-input" placeholder="Typ">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col pr-2">
                                    <button type="button" class="btn btn-sm btn-danger filter-reset">Reset</button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        <input style="display: none;" class="table-search form-control" id="materialTableSearch" placeholder="Hledat materiál..">
        <input style="display: none;" class="table-search form-control" id="categoryTableSearch" placeholder="Hledat kategorii..">
        <input style="display: none;" class="table-search form-control" id="depotsTableSearch" placeholder="Hledat sklad..">
        <input style="display: none;" class="table-search form-control" id="alertsTableSearch" placeholder="Hledat upozornění..">
        <!-- <input style="display: none;" class="table-search form-control" id="emptyTableSearch" placeholder="Hledat položku.."> -->




        <input style="display: none;" class="table-search form-control" id="inactiveTableSearch" placeholder="Hledat položku..">
    </div>

    <div class="card-body">
        <div class="tab-content">

            <!--start tab::items -->
            <div class="tab-pane fade show active" id="items_tab_pane" role="tabpanel">
                <div class="prevous_table d-none">
                <?php $components->render('table_ajax', ['ajaxUrl' => $ajaxUrls['depotTable'], 'tableId' => 'depotTable']); ?>
                </div>
              
              
            </div>
            <!--end tab::items -->

            <!--start tab::materials -->  
            <div class="tab-pane fade" id="material_tab_pane" role="tabpanel">
                <?php $components->render('table_ajax', ['ajaxUrl' => $ajaxUrls['materialTable'], 'tableId' => 'materialTable']); ?>       
            </div>
            <!--end tab::materials -->

            <!--start tab::depots -->
            <div class="tab-pane fade" id="depots_tab_pane" role="tabpanel">
                <?php $components->render('table_ajax', ['ajaxUrl' => $ajaxUrls['depotsTable'], 'tableId' => 'depotsTable']); ?>
            </div>
            <!--end tab::depots -->

            <!--start tab::depots -->
            <div class="tab-pane fade" id="alerts_tab_pane" role="tabpanel">
                <?php $components->render('table_ajax', ['ajaxUrl' => $ajaxUrls['alertsTable']??'', 'tableId' => 'alertsTable']); ?>
            </div>
            <!--end tab::depots -->

            <!--start tab::categories -->
            <div class="tab-pane fade" id="categories_tab_pane" role="tabpanel">
                <?php $components->render('table_ajax', ['ajaxUrl' => $ajaxUrls['categoryTable'], 'tableId' => 'categoryTable']); ?>
            </div>
            <!--end tab::categories -->

            <!--start tab::empty -->
            <div class="tab-pane fade" id="empty_tab_pane" role="tabpanel">
                <div class="new_table d-none">
                <?php $components->render('table_ajax', ['ajaxUrl' => $ajaxUrls['emptyTable'], 'tableId' => 'emptyTable']); ?>    
                </div>

                <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary"
                id="purchase_orders_table"
                data-options='<?php echo json_encode($local['table']['depot_items']); ?>'
            >
            </div>  
            </div>
            <!--end tab::empty -->

            <!--start tab::inactive -->
            <div class="tab-pane fade" id="inactive_tab_pane" role="tabpanel">
                <?php $components->render('table_ajax', ['ajaxUrl' => $ajaxUrls['inactiveTable'], 'tableId' => 'inactiveTable']); ?>
            </div>
            <!--end tab::inactive -->

            <!--start tab::gdn -->
            <div class="tab-pane fade" id="categories_tab_pane" role="tabpanel">
                <?php $components->render('table_ajax', ['ajaxUrl' => $ajaxUrls['categoriesTable'], 'tableId' => 'categoriesTable']); ?>
            </div>
            <!--end tab::gdn -->

        </div>
    </div>
</div>
<!--end::Card-->
<!--TODO: end_component-->
<!--end::Dashboard-->

<!-- Modals (@TODO: modal section?) -->
<?php echo view('backend/depot/add/category_modal.php'); ?>
<?php echo view('backend/depot/add/item_material_modal.php'); ?>

<?= $this->endSection() ?>