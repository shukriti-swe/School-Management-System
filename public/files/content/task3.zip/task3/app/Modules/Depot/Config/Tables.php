<?php declare(strict_types=1); 
namespace Depot\Config;

use CodeIgniter\Config\BaseConfig;

final class Tables extends BaseConfig {
    public string $depot_items = 'depot_items';

}