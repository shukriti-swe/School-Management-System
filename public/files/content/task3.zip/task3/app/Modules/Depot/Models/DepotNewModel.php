<?php declare(strict_types=1); 
namespace Depot\Models;

use App\Models\BaseModel;
use Depot\Entities\DepotOrderItem;

final class  DepotNewModel extends BaseModel
{
    protected $primaryKey           = 'id';
    protected $useAutoIncrement     = true;
    protected $useSoftDeletes       = false;
    protected $protectFields        = true;


    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;

    protected $allowedFields        = ['id','name','description','custom_barcode',
    'barcode','category','depot_item_category','unit','material_width','material_height','material_weight',
    'material_thickness','roll_length','note','price_in','price_in_custom','price_per_cut','unit_in','price_out','pricing_type','vat','active','name_id','double_sided','order_unit','lot_quantity','	is_draft','minimum_stock','created_at','updated_at'];


    public function __construct() {
        parent::__construct('id', 'asc');
        $this->table = config('Depot\Config\Tables')->depot_items;
 
    }

    public function getAllDepotItems_new(array $options)
    {
        // echo '<pre>';
        // print_r($options);
        // die();
        //global $options;
         return parent::getAllRowsForDatatable($options, [
            'selectWhere' => function ($builder) {

                /** @var BaseBuilder $builder */
                
                $builder->select('depot_items.*,
                depot_units.name as unitName,
                depot_items_categories.name as cat_name,
                depot_categories.name as categoryName,
                ds.depot_name
                ');
                $builder->join('depot_units', 'depot_units.id = depot_items.unit', 'LEFT');
                $builder->join('depot_categories', 'depot_categories.id = depot_items.category',    'LEFT');
                $builder->join('depot_items_categories', 'depot_items_categories.id = depot_items.  depot_item_category', 'LEFT');
                $builder->join("(
                    SELECT item_id, GROUP_CONCAT(dd.name ORDER BY dd.name SEPARATOR ', ') AS depot_name
                    FROM depot_stocks
                    INNER JOIN depots dd on dd.id = depot_id
                    GROUP BY item_id
        
                ) ds", "depot_items.id = ds.item_id", "LEFT");
              
            
                if (isset($this->rs_varaiable['onlyStock'])) {
                    
                    if ($this->rs_varaiable['onlyStock']) {
                        // echo 'hello';
                        //  die();
                        // Only items that are in stock
                        $builder->join('depot_stocks', 'depot_stocks.item_id = depot_items.id', isset($this->rs_varaiable['depotId']) ? 'RIGHT' : 'LEFT');
                        $builder->where('depot_stocks.stock >', 0);
                        //$builder->groupBy('depot_items.id');
                        
                        
                     }else{
                        
                        // Only items that are not in stock
                        $builder->join('depot_stocks', 'depot_stocks.item_id = depot_items.id', isset($this->rs_varaiable['depotId']) ? 'RIGHT' : 'LEFT');
                        $builder->where('depot_stocks.stock <=', 0)->orWhere('depot_stocks.stock IS NULL');
                        //$builder->groupBy('depot_items.id');
                    }
                }
               
            },
           
            'sortersAndFilters' => [
                'filters' => [
                    'default' => function ($field, $value, $builder) {
                        /** @var BaseBuilder $builder */

                        $builder->like($field, $value);
                    },


                    'fields' => [

                        'name' => function ($field, $value, $builder) {
                            /** @var BaseBuilder $builder */
                            $builder->like('depot_items.name', $value);
                        },

                        'barcode' => function($field, $value, $builder) {
                            /** @var BaseBuilder $builder */
                            $builder->like('depot_items.barcode', $value);
                        },

                        'material_weight' => function($field, $value, $builder) {
                            /** @var BaseBuilder $builder */
                            $builder->like('depot_items.material_weight', $value);
                        },

                        'material_width' => function($field, $value, $builder) {
                            /** @var BaseBuilder $builder */
                            $builder->like('depot_items.material_width', $value);
                        },

                        'categoryName' => function($field, $value, $builder) {
                            /** @var BaseBuilder $builder */
                            $builder->like('depot_categories.name', $value);
                        },
                    ],
                ],
            ],
            
         ]);
        // print_r($abc);
        // die();
    }
}
