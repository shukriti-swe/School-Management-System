<?php namespace App\Controllers\Backend;

use App\Controllers\Backend\BackendController;
use App\Libraries\KTDatatableRequest;
use App\Exceptions\PermissionException;
use App\Models\DepotModel;
use Depot\Libraries\DepotLib;
use Machines\Libraries\MachinesLib;
use Settings\Libraries\SettingsLib;

use Mpdf\Mpdf;

class Depot extends BackendController
{

    /*------------------------*/
    /* STATIC EVENT FUNCTIONS */
    /*------------------------*/

    /**
     * Check if items isnt under minimal treshold after a change in stock
     * 
     * @param int ID of item
     * @param int ID of depot
     * @param float amount changed
     * @param string direction of stock
     * 
     * @return bool
     */
    public static function checkItemAvailabilityAfterChange($itemId, $depotId, $amount, $direction)
    {
        if (!in_array($direction, ['remove'])) return FALSE; // perhaps extend this to reserve + set if needed
        
        // Lib
        $moduleLibrary = new DepotLib();

        // Get item + its stocks
        $item = $moduleLibrary->getDepotItem($itemId);
        $stocks = $moduleLibrary->getDepotItemStocks($itemId);

        // Calc current vs min
        $minStock = $item->minimum_stock;
        if ($minStock<=0) return FALSE; // Ignore zero set min stocks
        $totalStock = 0;
        foreach ($stocks as $stock) {
            $totalStock += $stock->stock;
        }

        // If current is less or equal to min
        if ($totalStock <= $minStock) {
            // Notify
            $model = new DepotModel();
            $model->createDepotAlert([
                'item_id' => $itemId,
                'depot_id' => $depotId,
                'minimum_stock' => $minStock,
                'recorded_stock' => $totalStock,
                'destocked' => $amount
            ]);

            return TRUE;
        } else return FALSE;
    }

    /**
     * Check for certain GDN types in depots (ie. store destock)
     * @param int ID of the GDN
     * @return bool
     */
    public static function checkItemDestockType($gdnId)
    {
        // Lib
        $moduleLibrary = new DepotLib();

        // Get GDN + its items
        $gdn = $moduleLibrary->getGdn($gdnId);
        $items = $moduleLibrary->getGdnItems($gdnId);
        if (!$gdn || empty($items)) return FALSE;

        // Model
        $model = new DepotModel();

        // Parse items
        foreach ($items as $item) {
            // Get depot + item
            $depot = $moduleLibrary->getDepot($item->depot_id);

            // Is store
            if ($depot->is_store) {
                $model->createDepotAlert([
                    'item_id' => $item->item_id,
                    'order_id' => @$item->order_id,
                    'depot_id' => $item->depot_id,
                    'destocked' => $item->quantity,
                    'store_destock' => TRUE
                ]);
            }
        }
    }

    /*---------------*/
    /*     MAIN      */
    /*---------------*/

    /**
     * INDEX
     */
	public function index() {

        if (!$this->permissions->hasPermission('view', 'depot')) {
			throw new PermissionException();
		}

        // Page title
        $this->pageData['pageTitle'] = 'Sklad';

        $machines = new MachinesLib();
        $this->pageData['machines'] = $machines->getMachines();
        $this->pageData['machinesUrl'] = base_url('/admin/machines/ajax/get-machines-s2-ajax');

        $settings = new SettingsLib();
        $this->pageData['parameters'] = $settings->getParameters();
        $this->pageData['parametersUrl'] = base_url('/admin/settings/ajax/get-parameters-s2-ajax/');
        $this->pageData['optionsUrl'] = base_url('/admin/settings/ajax/get-parameter-options-s2-ajax/');

        $moduleLibrary = new DepotLib();
        $this->pageData['units'] = $moduleLibrary->getUnits();
        $this->pageData['categories'] = $moduleLibrary->getDepotCategories();
        $this->pageData['depots'] = $moduleLibrary->getDepots();

        $formatOptions = model('\App\Models\SettingsModel')->getAllFormatOptions();
        $companyFormatOptions = model('\App\Models\SettingsModel')->getAllFormatOptions(FALSE);
        $weightOptions = model('\App\Models\SettingsModel')->getAllWeightOptions();

        $this->pageData['formats'] = array_merge($formatOptions, $companyFormatOptions);
        $this->pageData['weights'] = $weightOptions;

        // Depot item categories
        $this->pageData['depot_item_categories'] = model('\App\Models\DepotModel')->getDepotItemsCategoriesS2([]);

        // Ajax URIs
        $this->pageData['ajaxUrls']=[];
        
        $this->pageData['ajaxUrls']['depotTable'] = base_url('/admin/depot/ajax/get-depot-items-ajax');
        $this->pageData['ajaxUrls']['materialTable'] = base_url('/admin/depot/ajax/get-depot-materials-ajax');
        $this->pageData['ajaxUrls']['emptyTable'] = base_url('/admin/depot/ajax/get-empty-depot-items-ajax');
        $this->pageData['ajaxUrls']['inactiveTable'] = base_url('/admin/depot/ajax/get-inactive-depot-items-ajax');
        $this->pageData['ajaxUrls']['categoryTable'] = base_url('/admin/settings/ajax/get-depot-item-categories-ajax/');
        $this->pageData['ajaxUrls']['depotsTable'] = base_url('/admin/settings/ajax/get-depots-ajax');
        $this->pageData['ajaxUrls']['alertsTable'] = base_url('/admin/depot/ajax/get-depot-alerts-ajax');

        $this->pageData['ajaxUrls']['categoriesTable'] = base_url('/admin/depot/ajax/get-depot-categories-ajax');
        $this->pageData['ajaxUrls']['addCategory'] = base_url('/admin/depot/ajax/add-depot-category-ajax/');

        $this->pageData['local'] = [

            'table' => [
                'depot_items' => [
                    //'url' => '/admin/depot/ajax/get-depot-items-ajax-new',
                    'url' => '/admin/depot/ajax/get-empty-depot-items-ajax-new',
                    // 'urls' => [                    
                    //     'detail' => '/admin/purchase_orders/depot/detail',
                    //     'delete' => '',
                    // ],

                    'params' => []
                ],
            ],
        ];
   
        // Assets
        $this->pageData['assets']->add([
            'backend.depot.index.js',  
            //'backend.depot.filter.overview.js',
            'backend.depot.filter.overview.new.js'
        ]);

        return view('backend/depot/content', $this->pageData);
    }

    /**
     * Get all depot alerts for table
     */
    public function get_depot_alerts_ajax()
    {
        $request = &$this->request;
        $data = $request->getVar();

        $data = model('\App\Models\DepotModel')->getAllDepotAlerts(TRUE, $data);
        return $this->ajaxOK($data);
    }
    
    /**
     * Material
     * @param int $materialId
     */
	public function material($materialId) {

        if (!$this->permissions->hasPermission('view', 'depot')) {
			throw new PermissionException();
		}

        // Page title
        $this->pageData['pageTitle'] = 'Materiál';
        $name = model('\App\Models\DepotModel')->getDepotItemsName($materialId);
        if (!$name OR ($name && empty($name))) throw new PermissionException();

        $this->pageData['pageTitle'] .= ' - ' . $name[0]->name;
        $this->pageData['material'] = $name[0];

        $machines = new MachinesLib();
        $this->pageData['machines'] = $machines->getMachines();
        $this->pageData['machinesUrl'] = base_url('/admin/machines/ajax/get-machines-s2-ajax');

        $settings = new SettingsLib();
        $this->pageData['parameters'] = $settings->getParameters();
        $this->pageData['parametersUrl'] = base_url('/admin/settings/ajax/get-parameters-s2-ajax/');
        $this->pageData['optionsUrl'] = base_url('/admin/settings/ajax/get-parameter-options-s2-ajax/');

        $moduleLibrary = new DepotLib();
        $this->pageData['units'] = $moduleLibrary->getUnits();
        $this->pageData['categories'] = $moduleLibrary->getDepotCategories();
        $this->pageData['depots'] = $moduleLibrary->getDepots();

        // Ajax URIs
        $this->pageData['ajaxUrls']=[];
        $this->pageData['ajaxUrls']['depotTable'] = base_url('/admin/depot/ajax/get-depot-items-ajax');
        $this->pageData['ajaxUrls']['emptyTable'] = base_url('/admin/depot/ajax/get-empty-depot-items-ajax');
        $this->pageData['ajaxUrls']['inactiveTable'] = base_url('/admin/depot/ajax/get-inactive-depot-items-ajax');

        // Depot item categories
        $this->pageData['depot_item_categories'] = model('\App\Models\DepotModel')->getDepotItemsCategoriesS2([]);

        // Assets
        $this->pageData['assets']->add([
            'backend.depot.material.js'
        ]);

        return view('backend/depot/material', $this->pageData);
    }

    /**
     * Category
     * @param int $categoryId
     */
	public function depot_item_category($categoryId) {

        if (!$this->permissions->hasPermission('view', 'depot')) {
			throw new PermissionException();
		}

        // Page title
        $this->pageData['pageTitle'] = 'Kategorie';
        $category = model('\App\Models\DepotModel')->getDepotItemsCategory($categoryId);
        if (!$category OR ($category && empty($category))) throw new PermissionException();

        $this->pageData['pageTitle'] .= ' - ' . $category[0]->name;
        $this->pageData['category'] = $category[0];

        $machines = new MachinesLib();
        $this->pageData['machines'] = $machines->getMachines();
        $this->pageData['machinesUrl'] = base_url('/admin/machines/ajax/get-machines-s2-ajax');

        $settings = new SettingsLib();
        $this->pageData['parameters'] = $settings->getParameters();
        $this->pageData['parametersUrl'] = base_url('/admin/settings/ajax/get-parameters-s2-ajax/');
        $this->pageData['optionsUrl'] = base_url('/admin/settings/ajax/get-parameter-options-s2-ajax/');

        $moduleLibrary = new DepotLib();
        $this->pageData['units'] = $moduleLibrary->getUnits();
        $this->pageData['categories'] = $moduleLibrary->getDepotCategories();
        $this->pageData['depots'] = $moduleLibrary->getDepots();

        // Depot item categories
        $this->pageData['depot_item_categories'] = model('\App\Models\DepotModel')->getDepotItemsCategoriesS2([]);

        // Ajax URIs
        $this->pageData['ajaxUrls']=[];
        $this->pageData['ajaxUrls']['depotTable'] = base_url('/admin/depot/ajax/get-depot-items-ajax');
        $this->pageData['ajaxUrls']['emptyTable'] = base_url('/admin/depot/ajax/get-empty-depot-items-ajax');
        $this->pageData['ajaxUrls']['inactiveTable'] = base_url('/admin/depot/ajax/get-inactive-depot-items-ajax');

        // Assets
        $this->pageData['assets']->add([
            'backend.depot.category.js'
        ]);

        return view('backend/depot/category', $this->pageData);
    }

    /**
     * Depots
     * @param int $depotId
     */
    public function depots($depotId) {

        if (!$this->permissions->hasPermission('view', 'depot')) {
			throw new PermissionException();
        }
        
        $moduleLibrary = new DepotLib();

        // Page title
        $this->pageData['pageTitle'] = 'Sklad';
        $depot = $moduleLibrary->getDepot($depotId);
        if (!$depot OR ($depot && empty($depot))) throw new PermissionException();

        $this->pageData['pageTitle'] .= ' - ' . $depot->name;
        $this->pageData['depot'] = $depot;

        $machines = new MachinesLib();
        $this->pageData['machines'] = $machines->getMachines();
        $this->pageData['machinesUrl'] = base_url('/admin/machines/ajax/get-machines-s2-ajax');

        $settings = new SettingsLib();
        $this->pageData['parameters'] = $settings->getParameters();
        $this->pageData['parametersUrl'] = base_url('/admin/settings/ajax/get-parameters-s2-ajax/');
        $this->pageData['optionsUrl'] = base_url('/admin/settings/ajax/get-parameter-options-s2-ajax/');

        $this->pageData['units'] = $moduleLibrary->getUnits();
        $this->pageData['categories'] = $moduleLibrary->getDepotCategories();
        $this->pageData['depots'] = $moduleLibrary->getDepots();

        // Depot item categories
        $this->pageData['depot_item_categories'] = model('\App\Models\DepotModel')->getDepotItemsCategoriesS2([]);

        // Ajax URIs
        $this->pageData['ajaxUrls']=[];
        $this->pageData['ajaxUrls']['depotTable'] = base_url('/admin/depot/ajax/get-depot-items-ajax');
        $this->pageData['ajaxUrls']['emptyTable'] = base_url('/admin/depot/ajax/get-empty-depot-items-ajax');
        $this->pageData['ajaxUrls']['inactiveTable'] = base_url('/admin/depot/ajax/get-inactive-depot-items-ajax');

        // Assets
        $this->pageData['assets']->add([
            'backend.depot.depots.js'
        ]);

        return view('backend/depot/depots', $this->pageData);
    }

    /**
     * Depot item detail view
     * @param int $itemId
     */
    public function item($itemId)
    {
        // echo 'hii';
        // die();
        if (!$this->permissions->hasPermission('edit', 'depot')) {
			throw new \CodeIgniter\Exceptions\PageNotFoundException();
		}

        // Page title
        $this->pageData['pageTitle'] = 'Detail skladové položky';
        $this->pageData['breadcrumb'] = [
			'Sklad' => '/admin/depot',
		];

        // Vars / Data
        $moduleLibrary = new DepotLib();
        $machines = new MachinesLib();
        $settings = new SettingsLib();
        
        // Machine
        $this->pageData['machines'] = $machines->getMachines();
        $this->pageData['machinesUrl'] = base_url('/admin/machines/ajax/get-machines-s2-ajax');
        $this->pageData['includingMachines'] = (new \App\Models\MachineModel)->getDepotItemsMachinesIncluded($itemId);

        // Basic
        $this->pageData['item'] = $moduleLibrary->getDepotItem($itemId);

        if (isset($this->pageData['item']->unit)) $this->pageData['item']->unitName = $moduleLibrary->getUnit($this->pageData['item']->unit)->name ?? 'ks';
        else $this->pageData['item']->unitName = 'ks';

        $this->pageData['pageTitle'] .= ' - '.$this->pageData['item']->name;
        $this->pageData['units'] = $moduleLibrary->getUnits();
        $this->pageData['categories'] = $moduleLibrary->getDepotCategories();
        $this->pageData['depots'] = $moduleLibrary->getDepots();

        $this->pageData['itemQuantityPrice'] = model('\App\Models\PricelistModel')->getDepotItemSinglePrice($itemId);

        // Pricelist connection
        $this->pageData['pricelist'] = model('\App\Models\PricelistModel')->getDepotItemPricelist($itemId);

        if (!empty($this->pageData['pricelist'][0]) && !empty($this->pageData['pricelist'][0]['pricelist']->prices)) foreach ($this->pageData['pricelist'][0]['pricelist']->prices as $key => &$price) {
            // Regular inprice of item
            $item_price = $this->pageData['item']->price_in;
            $normal_price = $price->price;

            $price->resultPrice = $this->getResultPrice($normal_price, $item_price, $this->pageData['item']);
        }

        // Depot item names
        $this->pageData['names'] = model('\App\Models\DepotModel')->getDepotItemsNamesS2([]);

        // Depot item categories
        $this->pageData['depot_item_categories'] = model('\App\Models\DepotModel')->getDepotItemsCategoriesS2([]);

        // Params / options
        $this->pageData['parameters'] = $settings->getParameters();
        $this->pageData['parametersUrl'] = base_url('/admin/settings/ajax/get-parameters-s2-ajax/');
        $this->pageData['optionsUrl'] = base_url('/admin/settings/ajax/get-parameter-options-s2-ajax/');
        $this->pageData['selectedOptions'] = model('\App\Models\SettingsModel')->getDepotItemOptions($itemId);
        $this->pageData['selectedParameters'] = model('\App\Models\SettingsModel')->getDepotItemParameters($itemId);

        $this->pageData['prices'] = model('\App\Models\DepotModel')->getAllDepotItemPrices($itemId, FALSE);

        // Ajax URIs
        $this->pageData['ajaxUrls']=[];
        $this->pageData['ajaxUrls']['toggleItem'] = base_url('/admin/depot/ajax/toggle-depot-item-ajax/' . $itemId);
        $this->pageData['ajaxUrls']['formSubmit'] = base_url('/admin/depot/ajax/update-depot-item-ajax/' . $itemId);
        $this->pageData['ajaxUrls']['stocksTable'] = base_url('/admin/depot/ajax/get-depot-item-stocks-ajax/' . $itemId);

        $this->pageData['ajaxUrls']['addStock'] = base_url('/admin/depot/ajax/stock-up-depot-item-ajax/' . $itemId);
        $this->pageData['ajaxUrls']['moveStock'] = base_url('/admin/depot/ajax/move-depot-item-ajax/' . $itemId);
        $this->pageData['ajaxUrls']['removeStock'] = base_url('/admin/depot/ajax/stock-out-depot-item-ajax/' . $itemId);

        $this->pageData['ajaxUrls']['gdnTable'] = base_url('/admin/depot/ajax/get-gdns-ajax/'.$itemId);
        $this->pageData['ajaxUrls']['grnTable'] = base_url('/admin/depot/ajax/get-grns-ajax/'.$itemId);
        $this->pageData['ajaxUrls']['gmnTable'] = base_url('/admin/depot/ajax/get-gmns-ajax/'.$itemId);

        $this->pageData['ajaxUrls']['getPrices'] = base_url('/admin/depot/ajax/get-item-prices-ajax/' . $itemId);
        $this->pageData['ajaxUrls']['savePrices'] = base_url('/admin/depot/ajax/save-item-prices-ajax/' . $itemId);
        $this->pageData['ajaxUrls']['addItemPrice'] = base_url('/admin/depot/ajax/add-item-price-ajax/' . $itemId);
        $this->pageData['ajaxUrls']['removeItemPrice'] = base_url('/admin/depot/ajax/remove-item-price-ajax/' . $itemId);

        $this->pageData['ajaxUrls']['pricelistsUrl'] = base_url('/admin/depot/ajax/get-pricelists-s2-ajax/');
        $this->pageData['ajaxUrls']['setPricelist'] = base_url('/admin/depot/ajax/set-pricelist-ajax/' . $itemId);
        $this->pageData['ajaxUrls']['resetPricelist'] = base_url('/admin/depot/ajax/reset-pricelist-ajax/' . $itemId); // remove pricelist, set to default prices
        $this->pageData['ajaxUrls']['resetPricelistKeepPrices'] = base_url('/admin/depot/ajax/reset-pricelist-keep-prices-ajax/' . $itemId); // keep prices

        // Assets
        $this->pageData['assets']->add([
            'backend.depot.item.js',
            'backend.depot.item.prices.js'
        ]);

        // View
        return view('backend/depot/item', $this->pageData);
    }

    /**
     * Get pricelist price per item
     */
    private function getResultPrice($normal_price, $item_price, $item, $forceType = FALSE)
    {
        $depotLib = new DepotLib();

            // Base units
            $baseUnits = [
                'weight' => $depotLib->getUnitID('kg') ? $depotLib->getUnit($depotLib->getUnitID('kg')) : FALSE,
                'size' => $depotLib->getUnitID('m2') ? $depotLib->getUnit($depotLib->getUnitID('m2')) : FALSE,
                'piece' => $depotLib->getUnitID('ks') ? $depotLib->getUnit($depotLib->getUnit('ks')) : FALSE
            ];

            if ($forceType) $item->pricing_type = $forceType;

            if ($item->pricing_type==='percentil') {
                // Item has percentage based pricing
                switch ($item->unit_in) {
                    case ($baseUnits['weight']->id):
                        // kg
                        if ((!$item->material_width OR strlen($item->material_width)<=0) OR (!$item->material_height OR strlen($item->material_height)<=0) OR (!$item->material_weight OR strlen($item->material_weight)<=0)) return 0;

                        $pricePerUnit = ((($item->material_width*0.001) * ($item->material_height*0.001) * $item->material_weight) / 1000) * $item_price;
                        return $pricePerUnit + ($pricePerUnit * ($normal_price / 100));
                    break;
                    case ($baseUnits['size']->id):

                        if ($item->category == 3) {
                            if ((!$item->material_width OR strlen($item->material_width)<=0)) return 0;
                            return $item_price + ($item_price * ($normal_price / 100));
                        } else {
                            // m2
                            if ((!$item->material_width OR strlen($item->material_width)<=0) OR (!$item->material_height OR strlen($item->material_height)<=0)) return 0;

                            $pricePerUnit = ($item->material_width * $item->material_height) / (1000 * 1000) * $item_price;
                            return $pricePerUnit + ($pricePerUnit * ($normal_price / 100));
                        }
                    break;
                    default:
                        // ks
                        return $item_price + ($item_price * ($normal_price / 100));
                }
            } else {
                // Item has absolute pricing
                switch ($item->unit_in) {
                    case ($baseUnits['weight']->id):
                        // kg
                        if ((!$item->material_width OR strlen($item->material_width)<=0) OR (!$item->material_height OR strlen($item->material_height)<=0) OR (!$item->material_weight OR strlen($item->material_weight)<=0)) return 0;

                        $pricePerUnit = ((($item->material_width*0.001) * ($item->material_height*0.001) * $item->material_weight) / 1000) * $normal_price;
                        return $pricePerUnit;
                    break;
                    case ($baseUnits['size']->id):

                        if ($item->category == 3) {
                            if ((!$item->material_width OR strlen($item->material_width)<=0)) return 0;
                            return $normal_price;
                        } else {
                            // m2
                            if ((!$item->material_width OR strlen($item->material_width)<=0) OR (!$item->material_height OR strlen($item->material_height)<=0)) return 0;

                            $pricePerUnit = (($item->material_width * $item->material_height) / (1000 * 1000)) * $normal_price;
                            return $pricePerUnit;
                        }
                    break;
                    default:
                        // ks
                        return $normal_price;
                }
            }
    }

    /**
     * Get pricelists for select2
     */
    public function get_pricelists_s2_ajax(){
        $request = &$this->request;
        $data = model('\App\Models\PricelistModel')->getAllPricelistsS2((object)$this->request->getVar());
        return $this->ajaxOK(['results' => $data]);
    }

    /**
     * Set a pricelist for an depot item
     * @param int $itemId
     */
    public function set_pricelist_ajax($itemId){
        $request = &$this->request;
        $data = $request->getVar();

        if (model('\App\Models\PricelistModel')->setItemPricelist($itemId, $data['pricelist_id'])) {
            session()->setFlashdata('jsalert', ['type' => 'success', 'message' => 'Ceník byl úspěšně přidán.']);
            return $this->ajaxOK(['success' => true]);
        }
        else return $this->ajaxError(['error' => '']);
    }

    /**
     * Unset a pricelist for an depot item
     * @param int $itemId
     */
    public function reset_pricelist_ajax($itemId){
        $request = &$this->request;
        $data = $request->getVar();

        if (model('\App\Models\PricelistModel')->removeItemPricelist($itemId, $data['pricelist_id'])) {
            session()->setFlashdata('jsalert', ['type' => 'success', 'message' => 'Ceník byl úspěšně odebrán.']);

            return $this->ajaxOK(['success' => true]);
        }
        else return $this->ajaxError(['error' => '']);
    }

    /**
     * Reset item pricelist but keep prices
     * @param int $itemId
     */
    public function reset_pricelist_keep_prices_ajax($itemId){
        $request = &$this->request;
        $data = $request->getVar();

        $pricelist = model('\App\Models\PricelistModel')->getPricelist($data['pricelist_id']);
        if ($pricelist)
            $prices = $pricelist->prices;

        if (model('\App\Models\PricelistModel')->removeItemPricelist($itemId, $data['pricelist_id'])) {

            if (isset($prices)) {
                $moduleLibrary = new DepotLib();
                $moduleLibrary->removePricesFromItem($itemId); // Remove all existing prices (if)

                foreach ($prices as $price) {
                    unset($price->id);
                    unset($price->pricelist_id);

                    $moduleLibrary->addPriceToItem($itemId, $price->quantity, $price->price);
                }
            }

            session()->setFlashdata('jsalert', ['type' => 'success', 'message' => 'Ceník byl úspěšně odebrán a ceny zachovány.']);
            return $this->ajaxOK(['success' => true]);
        }
        else return $this->ajaxError(['error' => '']);
    }

    /** 
     * Destock depot item
     * @param int $itemId
     */
    public function stock_out_depot_item_ajax($itemId)
    {
        $request = &$this->request;
        $data = (object)$request->getVar();
        $moduleLibrary = new DepotLib();

        if ($moduleLibrary->changeDepotItemStock($itemId, $data->depot_id, $data->quantity, 'remove')) {
            $moduleLibrary->createGdn([(object)['item_id' => $itemId, 'depot_id' => $data->depot_id, 'quantity' => $data->quantity, 'price' => 0 ]], $data->reason); // delivery note
            return $this->ajaxOK(['success' => true]);
        }
        else return $this->ajaxError(['error' => '']);
    }

    /** 
     * Move depot item
     * @param int $itemId
     */
    public function move_depot_item_ajax($itemId)
    {
        $request = &$this->request;
        $data = (object)$request->getVar();
        $moduleLibrary = new DepotLib();

        if ($moduleLibrary->moveDepotItemStock($itemId, $data->depot_origin, $data->depot_target, $data->quantity)) {
            $moduleLibrary->createGmn((object)['item_id' => $itemId, 'quantity' => $data->quantity], $data->depot_origin, $data->depot_target); // move note
            return $this->ajaxOK(['success' => true]);
        }
        else return $this->ajaxError(['error' => '']);
    }

    /**
     * Get item depot notes
     * @param string $type
     * @param int $noteId
     */
    public function item_note($type, $noteId)
    {
        if (!$this->permissions->hasPermission('view', 'depot')) {
			throw new PermissionException();
		}

        $request = &$this->request;
        $moduleLibrary = new DepotLib();
        $mpdf = new Mpdf([
            'mode' => 'utf-8',
        ]);

        try {
            switch ($type) {
                case "grn":
                    $grn = $moduleLibrary->getGrn($noteId);
                    $grn_items = $moduleLibrary->getGrnItems($noteId);
                    $pdfFileName = "prijemka_{$grn->number_f}.pdf";

                    $user = $this->users->getUserById($grn->user_id);
                    $userName = $user->first_name . ' ' . $user->last_name;

                    foreach ($grn_items as $item) {
                        $item->depot = $moduleLibrary->getDepot($item->depot_id);
                    }
    
                    $mpdf->writeHTML(view('backend/depot/note/grn', ['grn' => $grn, 'items' => $grn_items, 'userName' => $userName]));
                break;
                case "gdn":
                    $gdn = $moduleLibrary->getGdn($noteId);
                    $gdn_items = $moduleLibrary->getGdnItems($noteId);
                    $pdfFileName = "vydejka_{$gdn->number_f}.pdf";
    
                    $user = $this->users->getUserById($gdn->user_id);
                    $userName = $user->first_name . ' ' . $user->last_name;

                    foreach ($gdn_items as $item) {
                        $item->depot = $moduleLibrary->getDepot($item->depot_id);
                    }

                    $mpdf->writeHTML(view('backend/depot/note/gdn', ['gdn' => $gdn, 'items' => $gdn_items, 'userName' => $userName]));
                break;
                case "gmn":
                    $gmn = $moduleLibrary->getGmn($noteId);
                    $pdfFileName = "presunka_{$gmn->number_f}.pdf";
    
                    $user = $this->users->getUserById($gmn->user_id);
                    $userName = $user->first_name . ' ' . $user->last_name;

                    $gmn->depot_origin_name = $moduleLibrary->getDepot($gmn->depot_origin)->name;
                    $gmn->depot_target_name = $moduleLibrary->getDepot($gmn->depot_target)->name;

                    $mpdf->writeHTML(view('backend/depot/note/gmn', ['gmn' => $gmn, 'userName' => $userName]));
                break;
            }
    
            $this->response->setContentType('Content-Type: application/pdf');
            $mpdf->Output($pdfFileName,\Mpdf\Output\Destination::INLINE);
        } catch (\Mpdf\MpdfException $e) {
            echo $e->getMessage();
        }
    }

    /**
     * Get grns ajax (table)
     * @param int $itemId
     */
    public function get_grns_ajax($itemId = NULL)
    {
        $request = &$this->request;
        $data = model('\App\Models\DepotModel')->getAllDepotNotes('grn', $itemId, TRUE, $request->getVar());
        return $this->ajaxOK($data);
    }

    /**
     * Get gdns ajax (table)
     * @param int $itemId
     */
    public function get_gdns_ajax($itemId = NULL)
    {
        $request = &$this->request;
        $data = model('\App\Models\DepotModel')->getAllDepotNotes('gdn', $itemId, TRUE, $request->getVar());
        return $this->ajaxOK($data);
    }

    /**
     * Get gmns ajax (table)
     * @param int $itemId
     */
    public function get_gmns_ajax($itemId = NULL)
    {
        $request = &$this->request;
        $data = model('\App\Models\DepotModel')->getAllDepotNotes('gmn', $itemId, TRUE, $request->getVar());
        return $this->ajaxOK($data);
    }

    /**
     * Get all item price settings
     * @param int $item_id
     */
    public function get_item_prices_ajax($item_id = NULL) {
        $data = model('\App\Models\DepotModel')->getAllDepotItemPrices($item_id, FALSE);
        return $this->ajaxOK($data);
    }

    /**
     * Get items lot quantity if set
     */
    public function get_item_min_quantity_ajax() {
        $request = &$this->request;
        $itemId = $request->getVar('itemId');

        if ($lotQuantity = model('\App\Models\DepotModel')->getItemLotQuantity($itemId)) return $this->ajaxOK(['lotQuantity' => $lotQuantity]);
        else return $this->ajaxError(['error' => '']);
    }

    /**
     * Save all item prices
     * @param int $item_id
     */
    public function save_item_prices_ajax($item_id = NULL) {

        $lib = new DepotLib();

        $data = $this->request->getPost();

        if (!isset($data['prices'])) {
            return $this->ajaxOK();
        }

        $success = true;
        foreach ($data['prices'] as $price) {
            $success = $success && $lib->updateItemPrice(intval($price['id']), [
                'quantity' => $price['quantity'],
                'price' => $price['price'],
            ]);
        }

        if (!$success) {
            return $this->ajaxError([
                'message' => "Některé záznamy se nepodařilo uložit"
            ]);
        }

        return $this->ajaxOK();
    }

    public function add_item_price_ajax($item_id) {
        $request = (object)$this->request->getVar();
        $moduleLibrary = new DepotLib();

        $result = $moduleLibrary->addPriceToItem($item_id, $request->quantity, $request->price, true);

        if (!$result) {
            return $this->ajaxError(['error' => '']);
        }
        
        return $this->ajaxOK($result);
    }

    public function remove_item_price_ajax($item_id) {
        $request = (object)$this->request->getVar();
        $moduleLibrary = new DepotLib();

        if ($moduleLibrary->removePriceFromItem($item_id, $request->id)) {
            return $this->ajaxOK(['success' => true]);
        }
        else {
            return $this->ajaxError(['error' => '']);
        }
    }

    /**
     * Add depot item view
     */
    public function addDepotItem()
    {
        if (!$this->permissions->hasPermission('publish', 'depot')) {
			throw new PermissionException();
		}

        // Page title
        $this->pageData['pageTitle'] = 'Nová skladová položka';
        $this->pageData['breadcrumb'] = [
			'Sklad' => '/admin/depot',
		];

        // Ajax URIs
        $this->pageData['ajaxUrls']=[];
        $this->pageData['ajaxUrls']['formSubmit'] = base_url('/admin/depot/ajax/add-depot-item-ajax/');
        
        // Vars
        $lib = new DepotLib();
        $this->pageData['units'] = $lib->getUnits();
        $this->pageData['categories'] = $lib->getDepotCategories();

        $machines = new MachinesLib();
        
        $this->pageData['machines'] = $machines->getMachines();
        $this->pageData['machinesUrl'] = base_url('/admin/machines/ajax/get-machines-s2-ajax');

        $settings = new SettingsLib();

        $this->pageData['parameters'] = $settings->getParameters();
        $this->pageData['parametersUrl'] = base_url('/admin/settings/ajax/get-parameters-s2-ajax/');
        $this->pageData['optionsUrl'] = base_url('/admin/settings/ajax/get-parameter-options-s2-ajax/'); // param id in url

        // Depot item categories
        $this->pageData['depot_item_categories'] = model('\App\Models\DepotModel')->getDepotItemsCategoriesS2([]);

        // Assets
        $this->pageData['assets']->add([
            'backend.depot.add.js'
        ]);

        // View
        return view('backend/depot/add/item', $this->pageData);
    }

    /**
     * UNIT
     * @param int $unitId
     */
    public function unit($unitId)
    {
        if (!$this->permissions->hasPermission('edit', 'depot')) {
			throw new PermissionException();
		}

        // Page title
        $this->pageData['pageTitle'] = 'Detail jednotky';
        $this->pageData['breadcrumb'] = [
			'Sklad' => '/admin/depot',
		];

        // Vars / Data
        $moduleLibrary = new DepotLib();
        $this->pageData['unit'] = $moduleLibrary->getUnit($unitId);
        $this->pageData['pageTitle'] .= ' - '.$this->pageData['unit']->name;

        $this->pageData['units'] = $moduleLibrary->getUnits();

        // Ajax URIs
        $this->pageData['ajaxUrls']=[];
        $this->pageData['ajaxUrls']['formSubmit'] = base_url('/admin/depot/ajax/update-depot-unit-ajax/'.$unitId);
        $this->pageData['ajaxUrls']['addUnit'] = base_url('/admin/depot/ajax/add-depot-unit-ajax/');
        $this->pageData['ajaxUrls']['addUnitConversion'] = base_url('/admin/depot/ajax/add-depot-unit-conversion-ajax/');
        $this->pageData['ajaxUrls']['conversionTable'] = base_url('/admin/depot/ajax/get-depot-unit-conversions-ajax/'.$unitId); 

        // Assets
        $this->pageData['assets']->add([
            'backend.depot.unit.js'
        ]);

        // View
        return view('backend/depot/unit', $this->pageData);
    }

    /**
     * Get units ajax (table)
     */
    public function get_depot_units_ajax()
    {
        $request = &$this->request;
        $data = model('\App\Models\DepotModel')->getAllDepotUnits(TRUE, $request->getVar());
        return $this->ajaxOK($data);
    }

    /**
     * Get unit conversions ajax (table)
     * @param int $unitId
     */
    public function get_depot_unit_conversions_ajax($unitId)
    {
        $request = &$this->request;
        $data = model('\App\Models\DepotModel')->getDepotUnitConversions($unitId, TRUE, $request->getVar());
        return $this->ajaxOK($data);
    }
    
    /**
     * Add depot unit
     */
    public function add_depot_unit_ajax(){
        $request = &$this->request;
        $moduleLibrary = new DepotLib();

        if ($unitId = $moduleLibrary->addUnit($request->getVar()['name'])) return $this->ajaxOK(['success' => true, 'unitId' => $unitId]);
        else return $this->ajaxError(['error' => '']);
    }

    /**
     * Add/save depot unit conversion record
     */
    public function add_depot_unit_conversion_ajax()
    {
        $request = &$this->request;
        $moduleLibrary = new DepotLib();
        $data = (object) $request->getVar();

        if (isset($data->conversion_id)) {
            // update
            if ($moduleLibrary->updateUnitConversion($data->conversion_id, $data->ratio)) return $this->ajaxOK(['success' => true]);
            else return $this->ajaxError(['error' => '']);
        } else {
            // insert
            if ($moduleLibrary->addUnitConversion($data->unit_1, $data->unit_2, $data->ratio)) return $this->ajaxOK(['success' => true]);
            else return $this->ajaxError(['error' => '']);
        }
    }

    /**
     * Delete a conversion record
     */
    public function delete_depot_unit_conversion_ajax()
    {
        $request = &$this->request;
        $moduleLibrary = new DepotLib();
        $data = (object) $request->getVar();

        if ($moduleLibrary->removeUnitConversion($data->unit_id)) return $this->ajaxOK(['success' => true]);
        else return $this->ajaxError(['error' => '']);
    }

    /** 
     * Update unit in DB
     * @param int $unitId
     */
    public function update_depot_unit_ajax($unitId)
    {
        $request = &$this->request;
        $moduleLibrary = new DepotLib();

        if ($moduleLibrary->updateUnit($unitId, $request->getVar())) return $this->ajaxOK(['success' => true]);
        else return $this->ajaxError(['error' => '']);
    }

    /**
     * CATEGORY
     * @param int $typeId
     */
    public function type($typeId)
    {
        if (!$this->permissions->hasPermission('edit', 'depot')) {
			throw new PermissionException();
		}

        // Page title
        $this->pageData['pageTitle'] = 'Detail typu';
        $this->pageData['breadcrumb'] = [
			'Sklad' => '/admin/depot',
		];

        // Vars / Data
        $moduleLibrary = new DepotLib();
        $this->pageData['type'] = $moduleLibrary->getDepotCategory($typeId);
        $this->pageData['pageTitle'] .= ' - '.$this->pageData['type']->name;

        // Ajax URIs
        $this->pageData['ajaxUrls']=[];
        $this->pageData['ajaxUrls']['formSubmit'] = base_url('/admin/depot/ajax/update-depot-category-ajax/'.$typeId);
        $this->pageData['ajaxUrls']['addCategory'] = base_url('/admin/depot/ajax/add-depot-category-ajax/');

        // Assets
        $this->pageData['assets']->add([
            'backend.depot.type.js'
        ]);

        // View
        return view('backend/depot/type', $this->pageData);
    }

    /** 
     * Update categorys in DB
     * @param int $categoryId
     */
    public function update_depot_category_ajax($categoryId)
    {
        $request = &$this->request;
        $moduleLibrary = new DepotLib();

        if ($moduleLibrary->updateDepotCategory($categoryId, $request->getVar())) return $this->ajaxOK(['success' => true]);
        else return $this->ajaxError(['error' => '']);
    }

    /**
     * Get categories ajax (table)
     */
    public function get_depot_categories_ajax()
    {
        $request = &$this->request;
        $tableVars = new KTDatatableRequest($request->getVar());

        $data = model('\App\Models\DepotModel')->getAllDepotTypes(TRUE, $tableVars);
        return $this->ajaxOK($data);
    }

    /**
     * Add depot category
     */
    public function add_depot_category_ajax(){
        $request = &$this->request;
        $moduleLibrary = new DepotLib();

        if ($categoryId = $moduleLibrary->addDepotCategory($request->getVar()['name'])) return $this->ajaxOK(['success' => true, 'categoryId' => $categoryId]);
        else return $this->ajaxError(['error' => '']);
    }

    /**
     * Combine multidim array into possible pair combinations
     * @param array $arrays
     */
    private function get_combinations($arrays) {
        $result = array();
        $arrays = array_values($arrays);
        $sizeIn = sizeof($arrays);
        $size = $sizeIn > 0 ? 1 : 0;
        foreach ($arrays as $array)
            $size = $size * sizeof($array);
        for ($i = 0; $i < $size; $i ++)
        {
            $result[$i] = array();
            for ($j = 0; $j < $sizeIn; $j ++)
                array_push($result[$i], current($arrays[$j]));
            for ($j = ($sizeIn -1); $j >= 0; $j --)
            {
                if (next($arrays[$j]))
                    break;
                elseif (isset ($arrays[$j]))
                    reset($arrays[$j]);
            }
        }
        return $result;
    }

    /**
     * Get parameter options
     */
    public function get_existing_param_options_ajax()
    {
        $request = &$this->request;
        $data = (object)$request->getVar();
        
        $settings = new SettingsLib();
        $allParameters = $settings->getParameters();
        $nameId = $data->name_id;

        // Go through other items in the list
        $otherItems = model('\App\Models\DepotModel')->getDepotItemsUnderName($data->name_id);
        $otherItemsOptions = [];

        foreach ($otherItems as $existingItem) {
            $existingItemOptions = model('\App\Models\SettingsModel')->getDepotItemOptions($existingItem['id']);
            foreach ($existingItemOptions as $existingItemOption) {
                $otherItemsOptions []= ['param_id' => $existingItemOption['parameter_id'], 'option_id' => $existingItemOption['option_id']];
            }
        }

        $otherItemsOptions = array_map("unserialize", array_unique(array_map("serialize", $otherItemsOptions)));

        $final = [];
        foreach ($otherItemsOptions as $pair) {
            $parameter = $settings->getParameter($pair['param_id']);
            $option = $settings->getOption($pair['option_id']);

            $final []= ['param_id' => $pair['param_id'], 'option_id' => $pair['option_id'], 'param_name' => $parameter->name, 'option_name' => $option->name];
        }

        return $this->ajaxOK($final);
    }

    /**
     * Get parameter options that are not assigned to a parameter
     */
    public function get_missing_param_options_ajax()
    {
        $request = &$this->request;
        $data = (object)$request->getVar();

        $selectedParams = isset($data->selected_parameters) ? $data->selected_parameters : [];
        $selectedOptions = isset($data->selected_options) ? $data->selected_options : [];
        
        $settings = new SettingsLib();
        $allParameters = $settings->getParameters();
        $nameId = $data->name_id;

        if (!empty($selectedOptions)) $selectedOptions = array_map(function($o){ return $o['option_id']; }, $selectedOptions);

        // Go through other items in the list
        $otherItems = model('\App\Models\DepotModel')->getDepotItemsUnderName($data->name_id);
        $otherItemsParamIds = [];
        $otherItemsOptionIds = []; 
        foreach ($otherItems as $existingItem) {

            $existingItemOptions = model('\App\Models\SettingsModel')->getDepotItemOptions($existingItem['id']);
            $existingItemOptionIds = array_map(function($o){ return $o['option_id']; }, $existingItemOptions);
            $existingParameterIds = array_map(function($o){ return $o['parameter_id']; }, $existingItemOptions);

            if (!empty($selectedOptions)) {
                foreach ($selectedOptions as $sOpt) {
                    if (in_array($sOpt, $existingItemOptionIds)) {
                        // This option exists
                        foreach ($existingItemOptionIds as $existingOpt) {
                            if ($existingOpt !== $sOpt) {
                                $otherItemsOptionIds []= $existingOpt;
                            }
                        }
                    }
                } 
            } else {
                foreach ($existingItemOptions as $existingItemOption) {
                    //if (!empty($selectedOptions) && in_array($existingItemOption['option_id'], $selectedOptions))
    
                    $otherItemsOptionIds []= $existingItemOption['option_id'];
                    $otherItemsParamIds []= $existingItemOption['parameter_id'];
                }
            }

            if (!empty($selectedParams)) {
                foreach ($selectedParams as $sParam) {
                    if (in_array($sParam, $existingParameterIds)) {
                        foreach ($existingParameterIds as $existingParam) {
                            if ($existingParam !== $sParam) {
                                $otherItemsParamIds []= $existingParam;
                            }
                        }
                    }
                }
            }
        }

        $final = [];
        foreach ($allParameters as $param) {
            if ((!empty($selectedParams) && !in_array($param->id, $selectedParams)) && $param->parameter_type!=='material') {
                if (in_array($param->id, $otherItemsParamIds)) {
                    $opts = model('\App\Models\SettingsModel')->getParameterOptionsS2((object)['parameter_ids' => [$param->id]]);

                    $param->options = [];
                    foreach ($opts as $opt) {
                        if (!in_array($opt['id'], $otherItemsOptionIds)) {
                            $param->options []= $opt;
                        }
                    }
    
                    if (!empty($param->options)) $final []= $param;
                }
            } else if (empty($selectedParams) && $param->parameter_type!=='material') {
                if (in_array($param->id, $otherItemsParamIds)) {
                    $opts = model('\App\Models\SettingsModel')->getParameterOptionsS2((object)['parameter_ids' => [$param->id]]);

                    $param->options = [];
                    foreach ($opts as $opt) {
                        if (!in_array($opt['id'], $otherItemsOptionIds)) {
                            $param->options []= $opt;
                        }
                    }
    
                    if (!empty($param->options)) $final []= $param;
                }
            }
        }

        return $this->ajaxOK($final);
    }

    // script fix (debug)
    public function fixItems()
    {
        // Lib
        $moduleLibrary = new DepotLib();

        // Get all format/weight ids
        $formatOptions = model('\App\Models\SettingsModel')->getAllFormatOptions();
        $companyFormatOptions = model('\App\Models\SettingsModel')->getAllFormatOptions(FALSE);
        $weightOptions = model('\App\Models\SettingsModel')->getAllWeightOptions();

        if ($formatOptions) $formatOptions = array_map(function ($o) {
            return $o['id'];
        }, $formatOptions);
        if ($companyFormatOptions) $companyFormatOptions = array_map(function ($o) {
            return $o['id'];
        }, $companyFormatOptions);
        if ($weightOptions) $weightOptions = array_map(function ($o) {
            return $o['id'];
        }, $weightOptions);

        // Merge two format types
        if (!empty($formatOptions)) $formatOptions = array_merge($formatOptions, $companyFormatOptions);

        // Get all depot items
        $depotItems = $moduleLibrary->getDepotItems();

        // Go
        foreach ($depotItems as $item) 
        {
            if ($item->material_width<=0 OR $item->material_height<=0 OR $item->material_weight<=0) {
                echo 'Fixing depot item #'.$item->id.PHP_EOL;
                $depotItemOptions = model('App\Models\SettingsModel')->getDepotItemOptions($item->id); // arr
                if ($depotItemOptions) {
                    foreach ($depotItemOptions as $option) {
                        $itemData = [];

                        if (in_array($option['option_id'], $formatOptions)) {
                            // Has a format option
                            $option_values = model('\App\Models\SettingsModel')->getOptionValues($option['option_id']);
                            if ($option_values) {
                                $itemData['material_width'] = $option_values[0]->value;
                                $itemData['material_height'] = $option_values[1]->value;
                            }
                        }

                        if (in_array($option['option_id'], $weightOptions)) {
                            // Has a weight option
                            $option_values = model('\App\Models\SettingsModel')->getOptionValues($option['option_id']);
                            if ($option_values) $itemData['material_weight'] = $option_values[0]->value;
                        }

                        // Save
                        $moduleLibrary->updateDepotItem($item->id, $itemData);
                    }
                }
            }
        }

        echo 'Done. :)';
    }

    /**
     * Remove an existing depot item
     */
    public function remove_depot_item_ajax()
    {
        echo 'hiii';
        die();
        $request = &$this->request;
        $data = (object)$request->getVar();
        $moduleLibrary = new DepotLib();

        // Del
        if (isset($data->itemId)) {
            if ($moduleLibrary->removeDepotItem($data->itemId)) {
                return $this->ajaxOK([]);
            } else return $this->ajaxError(['error' => true]);
        } else return $this->ajaxError(['error' => true]);
    }


    /** 
     * Add depotitem/s to DB
     */
    public function add_depot_item_ajax()
    {
        $request = &$this->request;
        $moduleLibrary = new DepotLib();
        $settingsLib = new SettingsLib();
        $data = $request->getVar();

        if (isset($data['depot_item_category'])) {
            // Create new category if supplied a string
            if (is_string($data['depot_item_category']) && !is_numeric($data['depot_item_category']) && strlen($data['depot_item_category'])>0) {
                $categoryId = model('\App\Models\DepotModel')->createDepotItemCategory($data['depot_item_category']);
                $data['depot_item_category'] = $categoryId;
            } else if (is_string($data['depot_item_category']) && strlen($data['depot_item_category'])<=0) {
                $data['depot_item_category'] = NULL;
            }
        }

        $customMaterialForm = FALSE;
        if (isset($data['customMaterialForm'])) $customMaterialForm = TRUE;

        $data['price_in'] = 0;

        // Base name
        $baseName = $data['name'];

        // Get all format/weight ids
        $formatOptions = model('\App\Models\SettingsModel')->getAllFormatOptions();
        $companyFormatOptions = model('\App\Models\SettingsModel')->getAllFormatOptions(FALSE);
        $weightOptions = model('\App\Models\SettingsModel')->getAllWeightOptions();

        if ($formatOptions) $formatOptions = array_map(function($o){ return $o['id']; }, $formatOptions);
        if ($companyFormatOptions) $companyFormatOptions = array_map(function($o){ return $o['id']; }, $companyFormatOptions);
        if ($weightOptions) $weightOptions = array_map(function($o){ return $o['id']; }, $weightOptions);

        // Merge two format types
        if (!empty($formatOptions)) $formatOptions = array_merge($formatOptions, $companyFormatOptions);

        // Check for existance of params/options
        if (isset($data['parameters']) && !empty($data['parameters']) && isset($data['options']) && !empty($data['options'])) {
            // Multiple items
            $settings = new SettingsLib();
            $combinations = [];
            $total_params = count($data['parameters']);
            $param_options = [];
            $empty_params = []; // params without options (filter setting)

            /*
            Memotechnická pomůcka pro tuhle funkcionalitu:
                1 item = Všechny parametry
                1 item = Od každého parameteru 1 hodnota

                Parametr = 3 hodnoty
                3 itemy => po 1 hodnotě

                2 parametry, 5 hodnot ['100g', 'mat, lesk, samet']

                100g mat
                100g lesk
                100g samet

                3 parametry, 3 hodnoty ['100g', 'mat', 'A4']

                100g mat A4
            */

            // Divide options by parameters (split it up)
            foreach ($data['options'] as $option_id) {
                $option = $settings->getOption($option_id);

                if (!isset($param_options[$option->parameter_id])) $param_options[$option->parameter_id] = [];
                $param_options[$option->parameter_id] []= $option;
            }

            // Get combos
            $combinations = $this->get_combinations($param_options);

            // Get single parameters
            foreach ($data['parameters'] as $parameter_id) {
                if (!isset($param_options[$parameter_id])) {
                    // No options for this parameter were set
                    $empty_params []= $parameter_id;
                }
            }

            // Go through combinations and create a prepared array to be pumped into DB
            $d = [];
            foreach ($combinations as $combo) {
                $it = ['name' => $baseName, 'option_ids' => []];

                foreach ($combo as $option){
                    $it['name'] .= ' ' . $option->name;

                    $it['description'] = $data['description'];
                    $it['price_in'] = $data['price_in'];
                    $it['unit'] = $data['unit'];
                    $it['unit_in'] = $moduleLibrary->getUnitID('ks'); // Default unit_in
                    $it['category'] = $data['category'];
                    $it['depot_item_category'] = $data['depot_item_category'];
                    $it['note'] = $data['note'];
                    $it['barcode'] = $data['barcode'];
                    $it['custom_barcode'] = $data['custom_barcode'];
                    $it['lot_quantity'] = $data['lot_quantity'];
                    $it['material_thickness'] = $data['material_thickness'];
                    $it['double_sided'] = $data['double_sided'];
                    $it['minimum_stock'] = $data['minimum_stock'];

                    // Dont overwrite if already set
                    if (!isset($it['material_width'])) $it['material_width'] = isset($data['material_width']) ? $data['material_width'] : NULL;
                    if (!isset($it['material_height'])) $it['material_height'] = isset($data['material_height']) ? $data['material_height'] : NULL;
                    if (!isset($it['material_weight'])) $it['material_weight'] = isset($data['material_weight']) ? $data['material_weight'] : 0;

                    if (in_array($option->id, $formatOptions)) {
                        // Has a format option
                        $format_values = model('\App\Models\SettingsModel')->getOptionValues($option->id);
                        if ($format_values) {
                            $it['material_width'] = $format_values[0]->value;
                            $it['material_height'] = $format_values[1]->value;
                        }
                    }

                    if (in_array($option->id, $weightOptions)) {
                        // Has a weight option
                        $weight_values = model('\App\Models\SettingsModel')->getOptionValues($option->id);
                        if ($weight_values) $it['material_weight'] = $weight_values[0]->value;
                    }

                    $it['option_ids'] []= $option->id;
                }

                // add to arr
                $d []= $it;
            }

            // Check for duplicates inside a name
            if ($customMaterialForm) {
                foreach ($d as $i => $finalizedItem) {
                    $optionIds = $finalizedItem['option_ids'];
                    $otherItems = model('\App\Models\DepotModel')->getDepotItemsUnderName($data['name_id']);

                    foreach ($otherItems as $existingItem) {
                        $existingItemOptions = model('\App\Models\SettingsModel')->getDepotItemOptions($existingItem['id']);
                        if ($existingItemOptions) $existingItemOptionIds = array_map(function($opt){ return $opt['option_id']; }, $existingItemOptions);
                        else $existingItemOptionIds = [];
                        
                        // Compare
                        if (!empty($existingItemOptions)) {
                            array_multisort($optionIds);
                            array_multisort($existingItemOptionIds);
                            if (serialize($optionIds) === serialize($existingItemOptionIds)) {
                                // Duplicate, remove from addition
                                unset($d[$i]);
                            }
                        }
                    }
                }
            }

            // Create a pricelist for all of these
            if ($customMaterialForm) {
                // If coming from the custom matform, check for existing pricelist
                $otherItems = model('\App\Models\DepotModel')->getDepotItemsUnderName($data['name_id']);

                if ($otherItems && !empty($otherItems)) {
                    $firstItem = $otherItems[0];

                    $itemPriceList = model('\App\Models\PricelistModel')->getDepotItemPricelist($firstItem['id']);
                    if ($itemPriceList) {
                        $priceList = [];
                        $priceList['id'] = $itemPriceList[0]['pricelist_id'];

                        foreach ($d as $item) {
                            // Match price_in
                            $item['price_in'] = $otherItems[0]['price_in'];
                        }
                    } else $priceList = model('\App\Models\PricelistModel')->addPriceList('Ceník '.$baseName, 'Automaticky generovaný ceník');
                } else {
                    $priceList = model('\App\Models\PricelistModel')->addPriceList('Ceník '.$baseName, 'Automaticky generovaný ceník');
                }
            } else {
                $priceList = model('\App\Models\PricelistModel')->addPriceList('Ceník '.$baseName, 'Automaticky generovaný ceník');
            }

            // Item count check
            if (count($d) <= 1) {
                // Check if adding multiple items, if not = mark
                $onlyOneItem = TRUE;
                $itemId = NULL;
            }

            // Create a name list for all of these / or set ID if existing
            if (!isset($data['name_id'])) $namelist = model('\App\Models\DepotModel')->createDepotItemsName($baseName);
            else $namelist = $data['name_id'];

            // Add to Databse
            foreach ($d as $row) {
                // assign namelist
                if ($namelist) {
                    $row['name_id'] = $namelist;
                }

                $row['double_sided'] = true;

                // Set itemId, add to db
                if ($itemId = $moduleLibrary->addDepotItem($row)) {
                    // Go through actual options
                    foreach ($row['option_ids'] as $option_id) {
                        // Add options to item
                        model('\App\Models\SettingsModel')->addDepotItemOption($itemId, $option_id);
                    }

                    // Go through parameters
                    foreach ($empty_params as $parameter_id) {
                        // Add param to item
                        model('\App\Models\SettingsModel')->addDepotItemParameter($itemId, $parameter_id);
                    }

                    // Allowed machines
                    if (isset($data['machine_id'])) {
                        $machines = new MachinesLib();

                        // add machines
                        foreach ($data['machine_id'] as $machineId) {
                            $machines->addDepotItemToMachine($machineId, $itemId);
                            if (isset($namelist)) $machines->addDepotNameToMachine($machineId, $namelist);
                        }
                    }

                    // Set the created pricelist connected with this item
                    if (isset($priceList) && isset($priceList['id'])) model('\App\Models\PricelistModel')->setItemPricelist($itemId, $priceList['id']);
                }
            }

            // Return itemId if just one item was added / return name as searchString for index table
            if (!isset($onlyOneItem)) return $this->ajaxOK(['success' => true, 'priceList' => $priceList]);
            else return $this->ajaxOK(['success' => true, 'itemId' => $itemId]);

        } else {
            if (!isset($data['name_id'])) $namelist = model('\App\Models\DepotModel')->createDepotItemsName($baseName);
            else $namelist = $data['name_id'];

            if ($namelist) {
                $data['name_id'] = $namelist;
            }

            $data['double_sided'] = true;

            // Check for other items in namecat, add pricelist if exists
            $otherItems = model('\App\Models\DepotModel')->getDepotItemsUnderName($data['name_id']);

            if ($otherItems && !empty($otherItems)) {
                $firstItem = $otherItems[0];

                $itemPriceList = model('\App\Models\PricelistModel')->getDepotItemPricelist($firstItem['id']);
                if ($itemPriceList) {
                    $priceList = [];
                    $priceList['id'] = $itemPriceList[0]['pricelist_id'];

                    // Match pricelist price_in
                    $data['price_in'] = $otherItems[0]['price_in'];
                }
            }

            // Add non-existing weights
            $paramOptionPair = FALSE;
            if (isset($data['material_weight'])) {
                $existingValues = [];
                $weightParam = null;
                foreach ($weightOptions as $wO) {
                    if (!$weightParam) $weightParam = $settingsLib->getParameterFromOption($wO);
                    $optionValue = $settingsLib->getOptionsValues($wO);
                    if ($optionValue && !empty($optionValue) && !empty($optionValue[0]->values)) {
                        $existingValues []= $width = (float)$optionValue[0]->values[0]->value;
                    }
                }

                // Not existing in array of values || no values in system
                if ($weightParam && (!empty($existingValues) && !in_array((float)$data['material_weight'], $existingValues)) || empty($existingValues)) {
                    $opId = $settingsLib->addOption((string)$data['material_weight'].'g', $weightParam->id, NULL, [['value' => (float)$data['material_weight'], 'parent_value' => NULL]], [], TRUE);
                    $paramOptionPair = ['option_id' => $opId, 'parameter_id' => $weightParam->id];
                }
            }

            // Single item with no params/options
            if ($itemId = $moduleLibrary->addDepotItem($data)) {
                // Param-option (weight)
                if ($paramOptionPair && !empty($paramOptionPair)) {
                    model('\App\Models\SettingsModel')->addDepotItemOption($itemId, $paramOptionPair['option_id']);
                    model('\App\Models\SettingsModel')->addDepotItemParameter($itemId, $paramOptionPair['parameter_id']);
                }

                // Set it if exists
                if (isset($priceList) && isset($priceList['id'])) model('\App\Models\PricelistModel')->setItemPricelist($itemId, $priceList['id']);

                // Allowed machines
                if (isset($data['machine_id'])) {
                    $machines = new MachinesLib();

                    // add machines
                    foreach ($data['machine_id'] as $machineId) {
                        $machines->addDepotItemToMachine($machineId, $itemId);
                        if (isset($namelist)) $machines->addDepotNameToMachine($machineId, $namelist);
                    }
                }
    
                return $this->ajaxOK(['success' => true, 'itemId' => $itemId]);
            }
            else return $this->ajaxError(['error' => '']);
        }
    }

    /** 
     * Stock up depotitem to DB
     */
    public function stock_up_depot_item_ajax($itemId)
    {
        $request = &$this->request;
        $data = (object)$request->getVar();
        $moduleLibrary = new DepotLib();
        // print_r($data);   
        // die();
        if ($moduleLibrary->addDepotItemStock($itemId, $data->depot_id, $data->quantity,$data->price_in)) {
            $moduleLibrary->createGrn([(object)['item_id' => $itemId, 'depot_id' => $data->depot_id, 'quantity' => $data->quantity,'per_price' => $data->per_price,'price' => $data->price_in??0 ]], $data->reason); // receival note
            return $this->ajaxOK(['success' => true]);
        }
        else return $this->ajaxError(['error' => '']);    
    }

    /**
     * Get depot items ajax (table)
     */
    public function get_depot_items_ajax()
    {
        $request = &$this->request;
        $data = $request->getVar();

        $data['active'] = 1;
        $data['onlyStock'] = true;

        $response = model(\App\Models\DepotModel::class)->getAllDepotItems(TRUE, $data);
        return $this->ajaxOK($response);
    }

    public function get_depot_items_ajax_new()
    {
        $request = &$this->request;
        $data = $request->getVar();
        // print_r($data);
        // die(); 
        $data['active'] = 1;
        $data['onlyStock'] = true;
        $response = model(\App\Modules\Depot\Models\DepotNewModel::class)->getAllDepotItems_new($data);
        return $this->ajaxOK($response);
    }
    /**
     * Get inactive depot items
     */
    public function get_inactive_depot_items_ajax()
    {
        $request = &$this->request;
        $data = $request->getVar();

        $data['active'] = 0;

        $response = model('\App\Models\DepotModel')->getAllDepotItems(TRUE, $data);
        return $this->ajaxOK($response);
    }

    /**
     * Get not-stocked depot items
     */
    public function get_empty_depot_items_ajax()
    {
        $request = &$this->request;
        $data = $request->getVar();

        $data['active'] = 1;
        $data['onlyStock'] = false;

        $response = model(\App\Models\DepotModel::class)->getAllDepotItems(TRUE, $data);
        return $this->ajaxOK($response);
    }

    public function get_empty_depot_items_ajax_new()
    {
    //    echo 'hii';
    //    die();
        $request = &$this->request;
        $data = $request->getVar();

        $data['active'] = 1;
        $data['onlyStock'] = false;

        // print_r($data);
        // die();
        $response = model(\App\Modules\Depot\Models\DepotNewModel::class)->getAllDepotItems_new($data);
        return $this->ajaxOK($response);
    }

    /**
     * Get materials
     */
    public function get_depot_materials_ajax()
    {
        $request = &$this->request;
        $data = model('\App\Models\DepotModel')->getAllDepotItemsNames(TRUE, $request->getVar());
        return $this->ajaxOK($data);
    }

    /**
     * Get categories
     */
    public function get_depot_item_categories_ajax()
    {
        $request = &$this->request;
        $data = model('\App\Models\DepotModel')->getAllDepotItemsCategories(TRUE, $request->getVar());
        return $this->ajaxOK($data);
    }

    /**
     * Get depot item stocks ajax (table)
     */
    public function get_depot_item_stocks_ajax($itemId)
    {
        $request = &$this->request;
        $data = model('\App\Models\DepotModel')->getAllDepotItemStocks($itemId, TRUE, $request->getVar());
        return $this->ajaxOK($data);
    }

    /** 
     * Toggle item active state
     */
    public function toggle_depot_item_ajax($itemId)
    {
        $request = &$this->request;
        $moduleLibrary = new DepotLib();
        
        if ($moduleLibrary->toggleDepotItem($itemId))
        {
            session()->setFlashdata('jsalert', ['type' => 'success', 'message' => 'Stav položky byl úspěšně upraven.']);
            return $this->ajaxOK(['success' => true]);
        } else return $this->ajaxError(['error' => '']);
    }

    /** 
     * Update task in DB
     */
    public function update_depot_item_ajax($itemId) {

        $moduleLibrary = new DepotLib();
        $settings = new SettingsLib();
        $settingsModel = new \App\Models\SettingsModel;

        /** @var \Depot\Models\DepotItemsModel */
        $depotItemsModel = model('\Depot\Models\DepotItemsModel');

        $data = $this->request->getPost();

        // Custom price in from this endpoint
        if (isset($data['price_in'])) {
            if (intval($data['price_in']) > 0) {
                $data['price_in_custom'] = TRUE;
            }
            else {
                $data['price_in_custom'] = FALSE;
            }
        }
        else {
            $data['price_in_custom'] = FALSE;
        }

        $machineIds = [];
        if (isset($data['machine_id']) && !empty($data['machine_id'])) {
            $machineIds = $data['machine_id'];
            unset($data['machine_id']);
        }


        $depotItemsModel->db()->transBegin();

        try {
        

            if (isset($data['depot_item_category'])) {
                // Create new category if supplied a string
                if (is_string($data['depot_item_category']) && !is_numeric($data['depot_item_category']) && strlen($data['depot_item_category'])>0) {
                    $categoryId = (new \App\Models\DepotModel)->createDepotItemCategory($data['depot_item_category']);
                    $data['depot_item_category'] = $categoryId;
                }
                elseif (is_string($data['depot_item_category']) && strlen($data['depot_item_category']) <= 0) {
                    $data['depot_item_category'] = NULL;
                }
            }

            if (isset($data['material_width']) && !$data['material_width']) {
                $data['material_width'] = NULL;
            }

            if (isset($data['material_height']) && !$data['material_height']) {
                $data['material_height'] = NULL;
            }

            if (isset($data['material_weight']) && !$data['material_weight']) {
                $data['material_weight'] = NULL;
            }

            if (isset($data['material_thickness']) && !$data['material_thickness']) {
                $data['material_thickness'] = NULL;
            }

            if (isset($data['unit_in']) && !$data['unit_in']) {
                $data['unit_in'] = NULL;
            }

            if (isset($data['name_id']) && (!$data['name_id'] || strlen($data['name_id'])<=0)) {
                $data['name_id'] = NULL;
            }

            // Params/options
            $param_options = [];
            $empty_params = [];

            $data_options = (isset($data['options'])) ? $data['options'] : [];
            $_data_options = [];
            foreach ($data_options as $opt_string) {
                if (!is_numeric($opt_string)) {
                    continue;
                }

                $_data_options []= intval($opt_string);
            }

            $data_parameters = (isset($data['parameters'])) ? $data['parameters'] : [];

            
            $mustHaveParameters = [
                'format' => false,
                'weight' => false,
            ];

            $mustHaveParametersTrans = [
                'format' => "Formát",
                'weight' => "Gramáž",
            ];

            foreach ($data_parameters as $_param_id) {
                if (!is_numeric($_param_id)) {
                    continue;
                }

                $_param_id = intval($_param_id);
                $_param = $settings->getParameter($_param_id);
                $_param_type = $_param->parameter_type;
                if (!array_key_exists($_param_type, $mustHaveParameters)) {
                    continue;
                }

                $_param_options = $settings->getOptions($_param_id);
                $_param_option_ids = array_map(fn ($opt) => intval($opt->id), $_param_options);
                $_has_some_option = false;
                foreach ($_param_option_ids as $_param_option_id) {
                    if (in_array($_param_option_id, $_data_options)) {
                        $has_some_option = true;
                        break;
                    }
                }

                if (!$has_some_option) {
                    continue;
                }

                $mustHaveParameters[$_param_type] = true;
            }

            foreach ($mustHaveParameters as $key => $has) {
                if (!$has) {
                    $depotItemsModel->db()->transRollback();

                    return $this->ajaxError([
                        'error' => true,
                        'error2' => true,
                        'error_type' => "missing_parameter",
                        'message' => "Chybí parametr/možnost pro " . $mustHaveParametersTrans[$key],
                    ]);
                }
            }


            
            $existing_options = $settingsModel->getDepotItemOptions($itemId);

            $temp = 23;

            // Divide options by parameters (split it up)
            foreach ($data_options as $option_id) {
                $option = $settings->getOption($option_id);

                if (!isset($param_options[$option->parameter_id])) {
                    $param_options[$option->parameter_id] = [];
                }

                $param_options[$option->parameter_id] []= $option;
            }

            // Get single parameters
            foreach ($data_parameters as $parameter_id) {
                if (!isset($param_options[$parameter_id])) {
                    // No options for this parameter were set
                    $empty_params []= $parameter_id;
                }
            }

            $existing_option_ids = [];
            if ($existing_options) {
                foreach ($existing_options as $option) {
                    $existing_option_ids []= $option['option_id'];
                }
            }

            // Add newly added
            foreach ($data_options as $option_id) {
                if (!in_array($option_id, $existing_option_ids)) {
                    $settingsModel->addDepotItemOption($itemId, $option_id);
                }
            }

            // Remove removed
            foreach ($existing_option_ids as $option_id) {
                if (!in_array($option_id, $data_options)) {
                    $settingsModel->removeDepotItemOption($itemId, $option_id);
                }
            }

            // Singular parameters
            $existing_parameters = $settingsModel->getDepotItemParameters($itemId);

            $temp = 23;

            $existing_param_ids = [];
            if ($existing_parameters) {
                foreach ($existing_parameters as $parameter) {
                    $existing_param_ids []= $parameter['parameter_id'];
                }
            }

            $temp = 23;

            // Add newly added
            foreach ($empty_params as $parameter_id) {
                if (!in_array($parameter_id, $existing_param_ids)) {
                    $settingsModel->addDepotItemParameter($itemId, $parameter_id);
                }
            }

            $temp = 23;

            // Remove removed
            foreach ($existing_param_ids as $parameter_id) {
                if (!in_array($parameter_id, $empty_params)) {
                    $settingsModel->removeDepotItemParameter($itemId, $parameter_id);
                }
            }

            if (!$moduleLibrary->updateDepotItem($itemId, $data)) {
                $depotItemsModel->db()->transRollback();
                return $this->ajaxError(['error' => '']);
            }

            // Allowed machines

            $machines = new MachinesLib();
            
            // Reset
            $machines->removeDepotItemFromMachines($itemId);

            // Set
            foreach ($machineIds as $machineId) {
                $machines->addDepotItemToMachine($machineId, $itemId);
                if (isset($data['name_id'])) {
                    $machines->addDepotNameToMachine($machineId, $data['name_id']);
                }
            }

        } catch (\Throwable $e) {
            $depotItemsModel->db()->transRollback();
            throw $e;
        }

        $depotItemsModel->db()->transComplete();

        return $this->ajaxOK(['success' => true]);
    }

}