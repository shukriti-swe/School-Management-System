<?php 
namespace Depot\Libraries;

use App\Libraries\Utils;
use Depot\Models\DepotsModel; // depots
use Depot\Models\DepotItemsModel; // items
use Depot\Models\DepotNamesModel; // names
use Depot\Models\DepotStocksModel; // stocks
use Depot\Models\DepotCategoriesModel; // categories
use Depot\Models\DepotGdnModel; // delivery notes
use Depot\Models\DepotGdnItemsModel; // delivery notes - items
use Depot\Models\DepotGrnModel; // receival notes
use Depot\Models\DepotGrnItemsModel; // receival notes - items
use Depot\Models\DepotGmnModel; // move notes
use Depot\Models\DepotUnitsModel; // units
use Depot\Models\DepotUnitConversionsModel; // units conversions
use Depot\Models\InventoriesModel; // inventories

use CodeIgniter\Events\Events;
use CodeIgniter\Config\BaseConfig;
use \CodeIgniter\Database\ConnectionInterface;
use Depot\Models\DepotItemPricesModel;
use CodeIgniter\Exceptions\ModelException;

class DepotLib {

    /** @Depot\Models\DepotsModel */
    protected $depots;

    /** @Depot\Models\DepotStocksModel */
    protected $stocks;

    /** @var \Depot\Models\DepotItemsModel */
    protected $items;

    /** @Depot\Models\DepotNamesModel */
    protected $names;

    /** @Depot\Models\DepotGdnModel */
    protected $gdn;

    /** @Depot\Models\DepotGdnItemsModel */
    protected $gdnItems;
    
    /** @Depot\Models\DepotGrnModel */
    protected $grn;

    /** @Depot\Models\DepotGrnItemsModel */
    protected $grnItems;

    /** @Depot\Models\DepotGmnModel */
    protected $gmn;

    /** @Depot\Models\DepotUnitsModel */
    protected $units;
    
    /** @Depot\Models\DepotUnitConversionsModel */
    protected $conversions;

    /** @Depot\Models\InventoriesModel */
    protected $inventories;

    protected $config;
    protected $db;

    public function __construct() {
        /** Init models */
        $this->depots = new DepotsModel();
        $this->items = model('\Depot\Models\DepotItemsModel');
        $this->names = new DepotNamesModel();
        $this->stocks = new DepotStocksModel();
        $this->categories = new DepotCategoriesModel();
        $this->gdn = new DepotGdnModel();
        $this->gdnItems = new DepotGdnItemsModel();
        $this->grn = new DepotGrnModel();
        $this->grnItems = new DepotGrnItemsModel();
        $this->gmn = new DepotGmnModel();
        $this->units = new DepotUnitsModel();
        $this->conversions = new DepotUnitConversionsModel();
        $this->inventories = new InventoriesModel();

        $this->config = config('Depot');
        $this->db = \Config\Database::connect();
    }

    /**
     * Generate incremented numbers for depot
     * 
     * @param string $type (note / inventory)
     * @param int $incremental the actual number (usually ID) 
     * @param string $customFormat custom formatting (according to the config, with % separators, one after another with INCREMENTAL preferably last)
     */
    public function generateDepotNumber($type = '', $incremental = 1, $customFormat = FALSE)
    {
        $format = '';
        switch ($type) {
            case 'note': case 'inventory': $format = $this->config->numberFormats[$type]; break;
            default: $format = $this->config->numberFormats['default']; 
        }
        if ($customFormat) $format = $customFormat;

        $parts = explode('%', $format);
        $number_f = '';
        $incremental_lead = 0;

        foreach ($parts as $part) {
            switch ($part) 
            {
                case 'YEAR': $number_f .= (string)date('y'); break;
                case 'MONTH': $number_f .= (string)date('m'); break;
                case 'DAY': $number_f .= (string)date('d'); break;
                case 'HOUR': $number_f .= (string)date('H'); break;
                case 'MINUTE': $number_f .= (string)date('i'); break;
                case 'SECOND': $number_f .= (string)date('s'); break;
                case '0': $incremental_lead = strlen($part); break;
                case 'INCREMENTAL': $number_f .= str_pad((string)$incremental, $incremental_lead, '0', STR_PAD_LEFT); break;
            }
        }

        return $number_f;
    }

    /**
     * Get next iterated number for a db item in depot table
     * 
     * @param string $table table name of the requested table, the table has to have a number int param
     * @return int the next number
     */
    public function getNextNumber($table)
    {
        $b = $this->db->table($table);
        $query = $b->orderBy('number', 'DESC')->get(1, 0);
        $result = $query->getResult();
        if (!empty($result)) {
            if (isset($result[0]->number)) return (int)$result[0]->number+1;
            else return 1;
        } else return 1;
    }

    /**
     * 
     * DEPOTS
     * Depots for products
     * 
     */

    /**
     * Check if depot with such name exist
     * @param string $depotName 
     * @return bool 
     */
    public function hasDepotByName($depotName) {
        $this->depots->where('name', $depotName);
        return $this->depots->countAllResults() > 0;
    }

    /**
     * Returns depot id or null by name
     * @param string $depotName 
     * @return int|null 
     */
    public function getDepotID($depotName) {
        $this->depots->where('name', $depotName);
        $result = $this->depots->find();

        if (!$result) {
            return NULL;
        }

        return $result[0]->id;
    }


    /**
     * Add depot
     * 
     * @param string $name
     * @param string $description
     * @return boolean/int
     */
    public function addDepot($name, $description)
    {
        if ($this->depots->insert(['name' => $name, 'description' => $description])) {
            $insertID = $this->depots->insertID();
            \CodeIgniter\Events\Events::trigger('depot_depot_added', $insertID);
            return $insertID;
        }
        else return FALSE;
    }

    /**
     * Get depot
     * 
     * @param int/null $depotId (NULL or depot ID)
     * @param string/null $depotName (NULL or depot NAME)
     * @return object the depot
     */
    public function getDepot($depotId = NULL, $depotName = NULL)
    {
        if ($depotId) $depot = $this->depots->find($depotId);
        else $depot = $this->depots->where('name', $depotName)->first();
        return $depot;
    }

    /**
     * Get depots
     * returns all depots in DB
     * @return array
     */
    public function getDepots()
    {
        return $this->depots->findAll();
    }

    /**
     * Remove depot
     * 
     * @param int/null $depotId (depot ID)
     * @return bool
     */
    public function removeDepot($depotId)
    {
        if ($this->depots->delete($depotId)){ 
            \CodeIgniter\Events\Events::trigger('depot_depot_removed', $depotId);
            return TRUE;
        }
        else return FALSE;
    }

    /**
     * Update depot
     * 
     * @param int/null $depotId (depot ID)
     * @param array/object $data (depot data)
     * @return bool
     */
    public function updateDepot($depotId, $data)
    {
        if ($this->depots->update($depotId, $data)) {
            if ($data['is_primary']==='1') {
                $b = $this->db->table('depots');
                $b->where('id !=', $depotId)->update(['is_primary' => 0]);
            }
            return TRUE;
        }
        else return FALSE;
    }

    /**
     * 
     * DEPOT CATEGORIES
     * Categories for products
     * 
     */


    /**
     * Add category
     * 
     * @param string $name
     * @return boolean
     */
    public function addDepotCategory($name)
    {
        if ($this->categories->insert(['name' => $name])) return TRUE;
        else return FALSE;
    }

    /**
     * Update depot category
     * 
     * @param int/null $categoryId depot category ID
     * @param array/object $categoryData data to be updated
     * @return bool
     */
    public function updateDepotCategory($categoryId, $categoryData = [])
    {
        return (bool)$this->categories->update($categoryId, $categoryData);
    }

    /**
     * Get depot
     * 
     * @param int/null $categoryId (NULL or depot_category ID)
     * @param string/null $categoryName (NULL or depot_category NAME)
     * @return object the depot category
     */
    public function getDepotCategory($categoryId = NULL, $categoryName = NULL)
    {
        if ($categoryId) $category = $this->categories->find($categoryId);
        else $category = $this->categories->where('name', $categoryName)->first();

        return $category;
    }

    /**
     * Get categories
     * returns all depots in DB
     * @return array
     */
    public function getDepotCategories()
    {
        return $this->categories->findAll();
    }

    /**
     * Remove category
     * 
     * @param int/null $categoryId (depot ID)
     * @return bool
     */
    public function removeDepotCategory($categoryId)
    {
        if ($this->categories->delete($categoryId)) return TRUE;
        else return FALSE;
    }


    /**
     * 
     * DEPOT ITEMS + STOCKS
     * depot items/products
     * 
     */


    /**
     * Add depot item
     * 
     * @param array/object $itemData
     * @return boolean/int
     */
    public function addDepotItem($itemData)
    {
        if ($this->items->insert($itemData)) {
            $insertID = $this->items->insertID();
            \CodeIgniter\Events\Events::trigger('depot_item_added', $insertID);
            return $insertID;
        }
        else return FALSE;
    }

    /**
     * Add depot item stock
     * 
     * @param int $itemId ID of the item
     * @param int $depotId ID of the depot
     * @param int/0 $amount amount
     * @param int/0 $reservedAmount reserved amount
     * @return boolean
     */
    public function addDepotItemStock($itemId, $depotId, $amount = 0,$price=0,$reservedAmount = 0)
    {
      
        $stock = $this->stocks->where(['item_id' => $itemId, 'depot_id' => $depotId])->first();
 
        if ($stock)
        { // 1 stock per depot/item ID pair
            if ($this->stocks->update($stock->id, ['stock' => bcadd($stock->stock, $amount, 4),'reserved_stock' => bcadd($stock->reserved_stock, $reservedAmount, 4),'total_price_in' => bcadd($stock->total_price_in, $price, 4)])) {
                \CodeIgniter\Events\Events::trigger('depot_stock_added', $itemId, $depotId, $amount,$price, $reservedAmount);
                return TRUE;
            }
            else return FALSE;
        } else 
        { // Newstock
            if ($this->stocks->insert(['item_id' => $itemId, 'depot_id' => $depotId, 'stock' => $amount, 'reserved_stock' => $reservedAmount,'total_price_in' => $price])) {
                \CodeIgniter\Events\Events::trigger('depot_stock_added', $itemId, $depotId, $amount,$price, $reservedAmount);
                return TRUE;
            }
            else return FALSE;
        }
    }


    /**
     * Change depot item stock
     * 
     * @param int $itemId ID of the item
     * @param int $depotId ID of the depot
     * @param int/0 $stock amount
     * @param int $direction direction of the change ( remove / reserve / add )
     * @return boolean
     */
    public function changeDepotItemStock($itemId, $depotId, $amount = 0, $direction = 'remove')
    {
        $stock = $this->stocks->where(['item_id' => $itemId, 'depot_id' => $depotId])->first();
        if ($stock) 
        {
            switch ($direction) {
                case 'remove':
                    if ($this->stocks->update($stock->id, ['stock' => ((float)$stock->stock - (float)$amount)])) {
                        \CodeIgniter\Events\Events::trigger('depot_stock_changed', $itemId, $depotId, $amount, $direction);
                        return TRUE;
                    }
                    else return FALSE;
                break;
                case 'reserve':
                    if ($this->stocks->update($stock->id, ['stock' => ((float)$stock->stock - (float)$amount), 'reserved_stock' => (float)$amount])) {
                        \CodeIgniter\Events\Events::trigger('depot_stock_changed', $itemId, $depotId, $amount, $direction);
                        return TRUE;
                    }
                    else return FALSE;
                break;
                case 'add':
                    if ($this->stocks->update($stock->id, ['stock' => ((float)$stock->stock + (float)$amount)])) {
                        \CodeIgniter\Events\Events::trigger('depot_stock_changed', $itemId, $depotId, $amount, $direction);
                        return TRUE;
                    }
                    else return FALSE;
                break;
                case 'set':
                    // FORCE SET (used by inventory)
                    if ($this->stocks->update($stock->id, ['stock' => $amount])) {
                        \CodeIgniter\Events\Events::trigger('depot_stock_changed', $itemId, $depotId, $amount, $direction);
                        return TRUE;
                    }
                    else return FALSE;
                break;
            }
        } else return FALSE;
    }

    /**
     * Move depot item stock to another stock (stock->stock)
     * 
     * @param int $itemId ID of the item
     * @param int $depotId ID of the depot
     * @param int $targetDepotId ID of the target depot
     * @param int/0 $stock amount
     * @return boolean
     */
    public function moveDepotItemStock($itemId, $depotId, $targetDepotId, $amount)
    {
        $stock = $this->stocks->where(['item_id' => $itemId, 'depot_id' => $depotId])->first();
        if ($stock) 
        {
            if ($this->stocks->update($stock->id, ['stock' => ((float)$stock->stock - (float)$amount)])) 
            {
                $targetStock = $this->stocks->where(['item_id' => $itemId, 'depot_id' => $targetDepotId])->first();
                if ($targetStock) 
                {
                    if ($this->stocks->update($targetStock->id, ['stock' => ((float)$targetStock->stock + (float)$amount)])) {
                        \CodeIgniter\Events\Events::trigger('depot_stock_moved', $itemId, $depotId, $targetDepotId, $amount);    
                        return TRUE;
                    }
                    else return FALSE;
                } 
                else 
                {
                    if ($this->stocks->insert(['item_id' => $itemId, 'depot_id' => $targetDepotId, 'stock' => (float)$amount, 'reserved_stock' => 0])) {
                        \CodeIgniter\Events\Events::trigger('depot_stock_moved', $itemId, $depotId, $targetDepotId, $amount);    
                        return TRUE;
                    }
                    else return FALSE;
                }
            }
        } else return FALSE;
    }

    /**
     * Get depot item
     * 
     * @param int/null $itemId depot item ID
     * @return object item
     */
    public function getDepotItem($itemId)
    {
        return $this->items->find($itemId);
    }
    public function getDepotName($nameId)
    {
        return $this->names->find($nameId);
    }

    /**
     * Update depot item
     * 
     * @param int/null $itemId depot item ID
     * @param array/object $itemData data to be updated
     * @return bool
     */
    public function updateDepotItem($itemId, $itemData = []) {
        if (is_null($itemData) || empty($itemData)) {
            return true;
        }

        return (bool) $this->items->update($itemId, $itemData);
    }

    /**
     * Get depot item stocks
     * 
     * @param int/null $itemId depot item ID
     * @return array array of stocks
     */
    public function getDepotItemStocks($itemId)
    {
        return $this->stocks
            ->where('item_id', $itemId)
            ->select("depot_stocks.*, depots.name as depot_name")
            ->join("depots", "depots.id = depot_stocks.depot_id")
            ->findAll()
        ;
    }

    /**
     * Get single depot item stock per depot
     * 
     * @param int $itemId depot item ID
     * @param int $depotId ID of the depot
     * @return object singular stock
     */
    public function getDepotItemStock($itemId, $depotId)
    {
        $this->stocks->where('item_id', $itemId)->where('depot_id', $depotId);
        return $this->stocks->first();
    }

    /**
     * Get all depot items
     * @return array
     */
    public function getDepotItems()
    {
        return $this->items->findAll();
    }

    /**
     * Remove depot item
     * 
     * @param int/null $categoryId (depot ID)
     * @return bool
     */
    public function removeDepotItem($itemId)
    {
        if ($this->items->delete($itemId)) {
            \CodeIgniter\Events\Events::trigger('depot_item_removed', $itemId);    
            return TRUE;
        }
        else return FALSE;
    }

    /**
     * Toggle depot item (active/inactive)
     * 
     * @param int/null $itemId (item ID)
     * @return bool
     */
    public function toggleDepotItem($itemId)
    {
        $item = $this->getDepotItem($itemId);
        if ($item) return (bool)$this->items->update($itemId, ['active' => !(bool)$item->active]);
        else return FALSE;
    }


    /**
     * 
     * DEPOT GDN/GRN/GMN
     * 
    */

    /**
     * Get single GRN
     * 
     * @param int $grnId ID of the grn
     * @return object
     */
    public function getGrn($grnId)
    {
        return $this->grn->find($grnId);
    }
    
    /**
     * Get all depotItems GRN records
     * 
     * @param int $itemId ID of the depot item
     * @return array|false
     */
    public function getItemGrns($itemId)
    {
        $b = $this->db->table('depot_grn');

        $b->select('depot_grn.*');
        $b->join('depot_grn_items', 'depot_grn.id = depot_grn_items.grn_id');
        $b->where('depot_grn_items.item_id', $itemId);

        $query = $b->get();
        $result = $query->getResult();

        if (!empty($result)) 
        {
            $total = [];
            foreach ($result as $grn) 
            {
                $grn->items = $this->grnItems->where('grn_id', $grn->id)->findAll();
                $total []= $grn;
            }

            return $total;
        } else return FALSE;
    }

    /**
     * Get single GRN items
     * 
     * @param int $grnId ID of the grn
     * @return array
     */
    public function getGrnItems($grnId)
    {
        return $this->grnItems->where('grn_id', $grnId)->findAll();
    }

    /**
     * Create GRN
     * 
     * @param array $depotItems [/stdClass(item_id, depot_id, quantity, price)]
     * @param string $depotNumber custom number if supplied
     * @return bool
     */
    public function createGrn($depotItems, $reason, $depotNumber = FALSE)
    {   
        //echo $depotItems;
        //echo $reason;
        // echo 'hello';
        //die();
        $grnNumber = $this->getNextNumber('depot_grn');
        $grn = $this->grn->insert([
            'number' => $grnNumber,
            'number_f' => $depotNumber ? $depotNumber : $this->generateDepotNumber('note', $grnNumber),
            'reason' => $reason,
            'user_id' => \Config\Services::session()->get('helper__auth_user_id'),
        ]);

        if ($grn) {
            $grnId = $this->grn->insertID();

            foreach ($depotItems as $item) {
                $depot_item = $this->getDepotItem($item->item_id);
                $stock = $this->getDepotItemStock($item->item_id, $item->depot_id);
    
                $item = [
                    'grn_id' => $grnId,
                    'item_name' => $depot_item->name,
                    'item_id' => $item->item_id,
                    'depot_id' => $item->depot_id,
                    'quantity' => $item->quantity,
                    'per_price'=>$item->per_price,
                    'price_in' => $item->price
                ];
                
                $this->grnItems->insert($item);
            }
        } else return FALSE;

        \CodeIgniter\Events\Events::trigger('depot_grn_created', $grnId);
        return TRUE;
    }

    /**
     * Get single GDN
     * 
     * @param int $gdnId ID of the gdn
     * @return object
     */
    public function getGdn($gdnId)
    {
        return $this->gdn->find($gdnId);
    }

    /**
     * Get all depotItems GDN records
     * 
     * @param int $itemId ID of the depot item
     * @return array|false
     */
    public function getItemGdns($itemId)
    {
        $b = $this->db->table('depot_gdn');

        $b->select('depot_gdn.*');
        $b->join('depot_gdn_items', 'depot_gdn.id = depot_gdn_items.gdn_id');
        $b->where('depot_gdn_items.item_id', $itemId);

        $query = $b->get();
        $result = $query->getResult();

        if (!empty($result)) 
        {
            $total = [];
            foreach ($result as $gdn) 
            {
                $gdn->items = $this->grnItems->where('gdn_id', $gdn->id)->findAll();
                $total []= $gdn;
            }

            return $total;
        } else return FALSE;
    }

    /**
     * Get single GDN items
     * 
     * @param int $gdnId ID of the gdn
     * @return array
     */
    public function getGdnItems($gdnId)
    {
        return $this->gdnItems->where('gdn_id', $gdnId)->findAll();
    }


    /**
     * Create GDN
     * 
     * @param array $depotItems [/stdClass(item_id, @order_id, depot_id, quantity, price)]
     * @param string $reason the reason for removal
     * @param string $depotNumber custom number if supplied
     * @return bool
     */
    public function createGdn($depotItems, $reason, $depotNumber = FALSE)
    {
        $gdnNumber = $this->getNextNumber('depot_gdn');
        $gdn = $this->gdn->insert([
            'number' => $gdnNumber,
            'number_f' => $depotNumber ? $depotNumber : $this->generateDepotNumber('note', $gdnNumber),
            'user_id' => \Config\Services::session()->get('helper__auth_user_id'),
            'reason' => $reason
        ]);

        if ($gdn) {
            $gdnId = $this->gdn->insertID();
            foreach ($depotItems as $item) {
                $depot_item = $this->getDepotItem($item->item_id);
                $stock = $this->getDepotItemStock($item->item_id, $item->depot_id);
    
                $item = [
                    'gdn_id' => $gdnId,
                    'item_name' => $depot_item->name,
                    'item_id' => $item->item_id,
                    'depot_id' => $item->depot_id,
                    'order_id' => @$item->order_id,
                    'quantity' => $item->quantity,
                    'price_in' => $item->price
                ];
    
                $this->gdnItems->insert($item);
            }
        } else return FALSE;

        \CodeIgniter\Events\Events::trigger('depot_gdn_created', $gdnId);
        return TRUE;
    }

    /**
     * Get single GMN
     * 
     * @param int $gmnId ID of the gmn
     * @return object
     */
    public function getGmn($gmnId)
    {
        return $this->gmn->find($gmnId);
    }

    /**
     * Get all depotItems GMN records
     * 
     * @param int $itemId ID of the depot item
     * @return array|false
     */
    public function getItemGmns($itemId)
    {
        $gmns = $this->gmn->where('item_id', $itemId)->findAll();
        if (!empty($gmns)) return $gmns;
        else return FALSE;
    }

    /**
     * Create GMN
     * 
     * @param object $depotItem /stdClass(item_id, quantity)
     * @param int $originDepot ID of the origin depot
     * @param int $targetDepot ID of the target depot
     * @param string $depotNumber custom number if supplied
     * @return bool
     */
    public function createGmn($depotItem, $originDepot, $targetDepot, $depotNumber = FALSE)
    {
        $db_item = $this->getDepotItem($depotItem->item_id);

        $gmnNumber = $this->getNextNumber('depot_gmn');
        $gmn = $this->gmn->insert([
            'number' => $gmnNumber,
            'number_f' => $depotNumber ? $depotNumber : $this->generateDepotNumber('note', $gmnNumber),
            'user_id' => \Config\Services::session()->get('helper__auth_user_id'),
            'item_id' => $depotItem->item_id,
            'item_name' => $db_item->name,
            'quantity' => $depotItem->quantity,
            'depot_origin' => $originDepot,
            'depot_target' => $targetDepot
        ]);

        if ($gmn) {
            \CodeIgniter\Events\Events::trigger('depot_gmn_created', $this->gmn->insertID());
            return TRUE;
        }
        else return FALSE;
    }

    /**
     * Add a price directive to an item
     * @param int $depotItemID ID of the item
     * @param int $qty_from starting quantity
     * @param int $qty_to ending quantity
     * @param int $price the price
     * 
     * @return boolean
     */
    public function addPriceToItem($depotItemID, $quantity, $price, $return_object = false) {
        $model = new DepotItemPricesModel();

        $result = $model->insert([
            'item_id' => $depotItemID,
            'quantity' => $quantity,
            'price' => $price,
        ], false);

        if (!$result) {
            return false;
        }

        if ($return_object) {
            $id = $model->getInsertID();
            return $model->find($id);
        }

        return true;
    }

    public function updateItemPrice(int $id, array $data) {
        $model = new DepotItemPricesModel();
        return $model->update($id, $data);
    }

    /**
     * Remove a price directive from an item
     * @param int $depotItemID ID of the item
     * @param int $id ID of the record
     * 
     * @return boolean
     */
    public function removePriceFromItem($depotItemID, $id) {
        $model = new DepotItemPricesModel();
        return (bool) $model->delete(intval($id));
    }
    
    public function removePricesFromItem($depotItemID) {
        $model = new DepotItemPricesModel();
        return (bool) $model->where('item_id', $depotItemID)->delete();
    }

    /**
     * Get Item price directive from a quantity
     * @param int $depotItemID ID of the item
     * @param int $quantity the amount
     * 
     * @return int/null price/null
     */
    public function GetItemPriceFromQuantity($depotItemID, $quantity) {
        $lowerBound = NULL;
        $upperBound = NULL;

        $model = new DepotItemPricesModel();

        $lowerBound = $model
            ->where('item_id', $depotItemID)
            ->where('quantity <=', $quantity)
            ->orderBy('ABS(quantity - ' . $quantity . ')')
            ->get(1, 0, true)->getRowObject()
        ;

        $upperBound = $model
            ->where('item_id', $depotItemID)
            ->where('quantity >=', $quantity)
            ->orderBy('ABS(quantity - ' . $quantity . ')')
            ->get(1, 0, true)->getRowObject()
        ;

        if (is_null($lowerBound) || is_null($upperBound)) {
            if (is_null($lowerBound) && is_null($upperBound)) {
                return NULL;
            }

            if (is_null($lowerBound) && !is_null($upperBound)) {
                return $upperBound->price;
            }

            if (!is_null($lowerBound) && is_null($upperBound)) {
                return $lowerBound->price;
            }
        }

        if ($lowerBound->id === $upperBound->id) {
            return $lowerBound->price;
        }

        $ratio = Utils::NormalizedRatio($lowerBound->quantity, $upperBound->quantity, $quantity, 8, 8);
        $lerp = Utils::Lerp($lowerBound->price, $upperBound->price, $ratio, 8, 2);
        return $lerp;        
    }

    /**
     * 
     * DEPOT UNITS
     * 
    */

    /**
     * Get unit
     * 
     * @param int $unitId ID of the unit
     * @return object the unit
     */
    public function getUnit($unitId)
    {
        return $this->units->find($unitId);
    }

    /**
     * Get unit name by its ID
     * @param string $unitName 
     * @return int|null
     */
    public function getUnitID($unitName) {
        $this->units->where('name', $unitName);
        $result = $this->units->find();
        if (!$result) {
            return NULL;
        }

        return $result[0]->id;
    }

    /**
     * Get all units
     * 
     * @return array the units
     */
    public function getUnits()
    {
        return $this->units->findAll();
    }

    /**
     * Has this particular unit, case-insesitive
     * @param string $unit 
     * @return boolean 
     */
    public function hasUnit($unit) {
        $this->units->where('name', $unit);
        return $this->units->countAllResults() > 0;
    }

    /**
     * Add unit
     * 
     * @param string $unitName name
     * @return bool
     */
    public function addUnit($unitName, bool $returnID = false)
    {
        $result = $this->units->insert(['name' => $unitName], true);

        if ($returnID) {
            return $result;
        }

        return (bool) $result;
    }

    /**
     * Update unit
     * 
     * @param int $unitId ID of unit
     * @param array $unitData data to be updated
     * @return bool
     */
    public function updateUnit($unitId, $unitData = [])
    {
        return (bool) $this->units->update($unitId, $unitData);
    }

    /**
     * Add unit conversion
     * 
     * @param int $fromUnit unit1
     * @param int $toUnit unit2
     * @param float $ratio the conversion ratio
     * @return bool
     */
    public function addUnitConversion($fromUnit, $toUnit, $ratio)
    {
        $exists = $this->getUnitConversion($fromUnit, $toUnit);
        if ($exists) return FALSE;

        if ($this->conversions->insert(['unit_1' => $fromUnit, 'unit_2' => $toUnit, 'ratio' => $ratio])) return TRUE;
        else return FALSE;
    }

    /**
     * Update conversion ratio
     * 
     * @param int $conversionId ID of the conversion
     * @param float $ratio ratio
     */
    public function updateUnitConversion($conversionId, $ratio)
    {
        if ($this->conversions->update($conversionId, ['ratio' => $ratio])) return TRUE;
        else return FALSE;
    }

    /**
     * Remove unit conversion
     * 
     * @param int $conversionId ID of the conversion
     * @return bool
     */
    public function removeUnitConversion($conversionId)
    {
        if ($this->conversions->delete($conversionId)) return TRUE;
        else return FALSE;
    }

    /**
     * Get unit conversion for two units
     * 
     * @param int $fromUnit ID of origin unit
     * @param int $to Unit ID of the target unit
     * @return object
     */
    public function getUnitConversion($fromUnit, $toUnit)
    {
        return $this->conversions->where('unit_1', $fromUnit)->where('unit_2', $toUnit)->first();
    }

    /**
     * Get all unit conversion for one unit or all conversions in system
     * 
     * @param int $fromUnit ID of origin unit (optional)
     * @param int $to Unit ID of the target unit (optional)
     * @return array/boolean
     */
    public function getUnitConversionForOneUnit($fromUnit = FALSE, $toUnit = FALSE)
    {
        if (!$fromUnit && $toUnit) return $this->conversions->where('unit_2', $toUnit)->findAll();
        else if ($fromUnit && !$toUnit) return $this->conversions->where('unit_1', $fromUnit)->findAll();
        else return $this->conversions->findAll();
    }

}