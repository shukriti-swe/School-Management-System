"use strict";

var BACKEND_PURCHASE_ORDERS_OVERVIEW = BACKEND_PURCHASE_ORDERS_OVERVIEW || (function() {
    const $instance = {

        tables: {
            /** @type {BoldDatatable} */
            depot_items: null,
        },

        tableOptions: {
            depot_items: null,
        },

        /**
         * @param {Event} event  
         */
        init: async function (event) {
            this.tables.depot_items = BoldDatatable.CreateFrom(
                document.querySelector("#purchase_orders_table"),
                this.tableColumns, this.tableActions,
                {
                    fixedActionsColumn: true
                }
            );

            this.tables.depot_items.sort("id", "asc"); //default sort
            
            setTimeout(() => this.tables.depot_items.redraw(), 400);

            this.tableOptions.depot_items = this.tables.depot_items.tableOptions;

            const filterAcc = document.querySelector(`#filter_accordion`);
            if (filterAcc) {
                let ddOptions = {
                    locale: 'cs',
                };

          //       for (const dtp of filterAcc.querySelectorAll(`.datetimepicker-input`)) {
          //           $(dtp).datetimepicker(ddOptions);
          //       }

                BACKEND_TABLE.initFilters(this.tables.depot_items.table, filterAcc);
            }
            
            this.fireEvents();
        },
        
        // fireEvents: function() {
        //     let sendModal = document.querySelector("#sendModal");
        //     let buttonSend = sendModal.querySelector('button.js-send-modal-send');

        //     buttonSend.addEventListener('click', async event => {                
        //         const url = sendModal.getAttribute('data-ajax');
        //         const input = sendModal.querySelector(`input[name=emails]`);
        //         const emails = input.value;

        //         const id = sendModal.getAttribute('data-id');

        //         let response = null;

        //         try {
        //             response = await BOLD._postPromised(url, {
        //                 id: id,
        //                 emails: emails,
        //             });

        //         } catch (e) {
        //             console.log(e);
        //             N.show('error', e.response.message);
        //             return false;
        //         }

        //         console.log(response);
        //         N.show('success', response.response.message);

        //         $(sendModal).modal('hide');

        //         return await new Promise((resolve, reject) => {
        //             setTimeout(() => {
        //                 resolve(true);
    
        //             }, 1400);
        //         });
        //     });
        // },

//         onDetail: async function (data, tableID) {
//             window.location.assign( this.tableOptions.purchase_orders.urls.detail + '/' + data.id );
//         },

        onDetail: async function(data, tableID) {
            window.location.assign('/admin/depot/item/' + data.id);
        },
        onDelete: async function(data, tableID) {
            window.location.assign('/admin/depot/ajax/remove-depot-item-ajax');
        },

        // onSend: async function(data, tableID) {
        //     if (!['active', 'awaiting'].includes(data.state)) {
        //         return;
        //     }

        //     let modal = document.querySelector("#sendModal");

        //     modal.setAttribute('data-id', data.id);

        //     $(modal).modal('show');

        //     let input = modal.querySelector(`input[name="emails"]`);
        //     input.value = data.supplier_email;

        //     return true;
        // },

//         onDelete: async function(data, tableID) {
//         },

        /** @type {BoldDatatableOptionsColumn[]} */
        tableColumns: [
            { field: 'name', title: 'Název'},
            { field: 'barcode', title: 'SAP'},
            {
              field: 'material_weight', title: 'Gramáž',
            },
            {
               field: 'material_width', title: 'Formát',
               
            },
            { field: '', title: 'Dostupné'},
            { field: 'categoryName', title: 'Typ'},
                         
        ],

     

//         /** @type {BoldDatatableAction[]} */
//         tableActions: [
//             { id: 'pdf', text: '', buttonClasses: ['btn-primary far fa-eye'], callback: (data, tableID) => $instance.onDetail(data, tableID) },
//             { id: 'detail', text: '', buttonClasses: ['btn-danger ki ki-close icon-md'], callback: (data, tableID) => $instance.onDelete(data, tableID) },
           
//         ],
    };

    window.addEventListener('DOMContentLoaded', event => $instance.init(event));
    return $instance;
})();
