<?php declare(strict_types=1); 

namespace Depot\Entities;

use App\Entities\BaseEntity;

/**
 * DepotPurchaseOrderItem
 * 
 * @property string $name 

 */
final class DepotOrderItem extends BaseEntity {
    public function __construct() {
        parent::__construct([
            'name' => 'string',
        ]);
    }
}

